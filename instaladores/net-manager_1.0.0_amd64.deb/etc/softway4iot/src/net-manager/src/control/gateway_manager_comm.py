import os
from src.comm.ovsctl import OvsCtl


class GatewayManagerComm:
    def __init__(self, phy_interface):
        """

        :param phy_interface: Physical Interface
        """
        self.phy_interface = phy_interface
        self.ovs = OvsCtl('localhost')

    def add_of_rule(self):
        """

        :return:
        """
        pass

    def redirect_port(self, interface, ip):
        """
        TODO
        :return:
        """

    def add_port_container(self, container_name, bridge, gateway, ip, mac_address=None, port='eth1'):
        """
        Add port in container
        :param ip:
        :param container_name:
        :param bridge:
        :param port:
        :param gateway:
        :return:
        """
        if mac_address:
            command = 'sudo ovs-docker add-port ' + str(bridge) + ' ' + str(port) + ' ' + container_name + \
                      ' --ipaddress=' + ip + ' --gateway=' + gateway + ' --macaddress=' + mac_address + ' --mtu=1400'
        else:
            command = 'sudo ovs-docker add-port ' + str(bridge) + ' ' + str(port) + ' ' + container_name + \
                      ' --ipaddress=' + ip + ' --gateway=' + gateway + ' --mtu=1400'

        os.system(command)

    def del_port_container(self, container_name, bridge):
        """
        Delete port of container
        :param ip:
        :param container_name:
        :param bridge:
        :param port:
        :param gateway:
        :return:
        """
        command = 'sudo ovs-docker del-ports ' + str(bridge) + ' ' + container_name

        os.system(command)

    def add_gre_port_tunnel(self, gateway_id, gateway_ip):
        """

        :return:
        """
        command = "ovs-vsctl add-port br-data gre_gw_" + str(gateway_id) + " -- set Interface gre_gw_" + \
                  str(gateway_id) + " type=gre options:remote_ip=" + str(gateway_ip)

        os.system(command)

        # self.ovs.add_vxlan_port('br-data', gateway_id, gateway_ip)

    def add_vxlan_port_tunnel(self, gateway_id, gateway_ip):
        """

        :return:
        """
        command = "ovs-vsctl add-port br-control vxlan_gw_" + str(gateway_id) + " -- set Interface vxlan_gw_" + \
                  str(gateway_id) + " type=vxlan options:remote_ip=" + str(gateway_ip)

        os.system(command)

        # self.ovs.add_gre_port('contivVxlanBridge', gateway_id, gateway_ip)
