#!/bin/bash

GWTYPE="pc"

gateway_manager_ip=$1
phy_interface=$2
user_gm=$3

subnet_data=$4
subnet_control=$5

# Copiar configuracoes para as VMS:
scp * $user_gm@$gateway_manager_ip:/home/$user_gm
ssh -t $user_gm@$gateway_manager_ip "chmod +x /home/$user_gm/*"

# Instalacao de pacotes:
ssh -t $user_gm@$gateway_manager_ip "sudo /home/$user_gm/installations.sh"

# Limpar configuracoes antigas:
ssh -t $user_gm@$gateway_manager_ip "sudo /home/$user_gm/clear_installation.sh"

# Configuracoes iniciais Gateway Manager:
ssh -t $user_gm@$gateway_manager_ip "sudo /home/$user_gm/initial_setup_bridges.sh $phy_interface $subnet_data $subnet_control 0"