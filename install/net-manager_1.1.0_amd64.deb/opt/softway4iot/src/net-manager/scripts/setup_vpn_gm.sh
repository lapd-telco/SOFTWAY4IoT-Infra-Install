#!/bin/bash

cat >> /etc/sysctl.conf << EOF
net.ipv4.ip_forward = 1
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
EOF

sysctl -p /etc/sysctl.conf

# Generate Preshared Key:
mkdir .conf/
openssl rand -base64 64 > ./conf/key

cat >> ipsec.conf << EOF
# basic configuration
config setup
        charondebug="all"
        uniqueids=yes
        strictcrlpolicy=no
EOF

cp ipsec.conf /etc/ipsec.conf
rm ipsec.conf

cat >> ipsec.secrets << EOF
# source      destination
EOF

cp ipsec.secrets /etc/ipsec.secrets
rm ipsec.secrets
