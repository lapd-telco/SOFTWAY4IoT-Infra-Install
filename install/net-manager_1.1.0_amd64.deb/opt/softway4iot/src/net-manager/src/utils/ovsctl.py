# coding=utf-8
import logging

from src.utils import bridge as ovs_bridge


class OvsCtl:
    logging.getLogger(__name__)
    address = None  # type: str
    ovs_bridge = None  # type: ovs_bridge.OVSBridge

    @staticmethod
    def get_instance():
        """ Static access method.
        :rtype: OvsCtl
        :return: OvsCtl instance
        """
        OVSDB_ADDR = 'tcp:{}:{}'.format('localhost', 6640)
        return OvsCtl(host=OVSDB_ADDR)

    @staticmethod
    def get_address(host='localhost', port=6640):
        return 'tcp:{}:{}'.format(host, port)

    def __init__(self, host):
        # OVSBridge instance instantiated later
        self.ovs_bridge = None
        self.address = self.get_address(host)

    def _ovsdb_connection(self, br_name):
        """

        :param br_name:
        :rtype: ovs_bridge.OVSBridge
        :return: ovs_bridge
        """
        try:
            self.ovs_bridge = ovs_bridge.OVSBridge(ovs_bridge.CONF, self.address, br_name)
        except Exception as e:
            logging.exception('Cannot initiate OVSDB connection: %s', e)
            return None

        return self.ovs_bridge

    def add_patch(self, br_name, patch0, patch1):
        """
        For all new switch the patch will connect then on ovsbr0
        """
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None

        ovs.add_patch(patch0, patch1)

    def add_br(self, br_name):
        """
        TODO: desc.
        """
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None

        ovs.add_bridge()

    def del_bridge(self, br_name):
        """
        TODO: desc.
        """
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None

        ovs.del_bridge()

    def add_port(self, br_name, port):
        """
        TODO: desc.
        """
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None

        ovs.add_port(port)

    def add_internal_port(self, br_name, port):
        """
        TODO: desc.
        """
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None

        ovs.add_internal_port(port)

    def del_port(self, br_name, port):
        """
        TODO: desc.
        """
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None

        ovs.del_port(port)

    def del_patch(self, br_name, patch):
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None
        ovs.del_port(patch)

    def get_port_list(self, br_name):
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return []

        return ovs.get_port_name_list()

    def get_dpid(self, br_name):
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None

        return ovs.get_datapath_id()

    def exists(self, br_name):
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None

        return ovs.br_exists()

    def add_vlan(self, br_name, port, vlan_id):
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None

        return ovs.add_vlan(port, vlan_id)

    def set_protocol(self, br_name, ofproto):
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None
        return ovs.add_protocol(ofproto)

    def set_controller(self, br_name, ip, port):
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None
        controller = "tcp:%s:%s" % (ip, port)
        return ovs.set_controller([controller, ])

    def del_controller(self, br_name):
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None
        return ovs.del_controller()

    def get_ofport(self, br_name, port_name):
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None
        return ovs.get_ofport(port_name)

    def add_vxlan_port(self, br_name, name, remote_ip, local_ip=None, key="flow", ofport=None, dst_port=None):
        """
        Add VLAN port in OVS
        :type br_name: object
        :param name: Port name to be created
        :param remote_ip: Remote IP address of tunnel
        :param local_ip: Local IP address of tunnel
        :param key: Key of GRE or VNI of VxLAN
        :param ofport: Requested OpenFlow port number
        """
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None

        ovs.add_vxlan_port(name, remote_ip, local_ip, key=key, ofport=ofport, dst_port=dst_port)

    def add_gre_port(self, br_name, name, remote_ip, local_ip=None, key="flow", ofport=None, dst_port=None):
        """
        Add GRE port in OVS
        :type br_name: object
        :param name: Port name to be created
        :param remote_ip: Remote IP address of tunnel
        :param local_ip: Local IP address of tunnel
        :param key: Key of GRE or VNI of VxLAN
        :param ofport: Requested OpenFlow port number
        """
        ovs = self._ovsdb_connection(br_name)
        if ovs is None:
            return None

        ovs.add_gre_port(name, remote_ip, local_ip, key=key, ofport=ofport)
