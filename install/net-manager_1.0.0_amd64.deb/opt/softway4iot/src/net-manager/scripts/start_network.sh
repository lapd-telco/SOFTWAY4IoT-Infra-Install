#!/bin/bash

iptables-restore < /home/labora/iptables-save

ifconfig c-data 10.249.1.1/16 up
ifconfig c-control 10.250.1.1/16 up