# SOFTWAY4IoT-F3-Gw-monitor
Monitor status of apllications, collect stats about CPU, memory and Network and recovery of faults.
