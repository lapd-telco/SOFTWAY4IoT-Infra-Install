from datetime import datetime

import psutil
from dateutil.tz import tzutc

from sw4iotdatabase.models import UpdatedAtModel
from sw4iotdatabase.schemas import UpdatedAtSchema


def monitor_gateway_stats(db, id):
    stats = {
        'net': {
            'bytes_in': psutil.net_io_counters().bytes_recv,
            'bytes_out': psutil.net_io_counters().bytes_sent,
        },
        'cpu': {
            'count': psutil.cpu_count(),
            'percent': psutil.cpu_percent(),
            'frequency': {
                'current': psutil.cpu_freq().current,
                'max': psutil.cpu_freq().max,
                'min': psutil.cpu_freq().min
            }
        },
        'memory': {
            "total": psutil.virtual_memory().total,
            "available": psutil.virtual_memory().available,
            "percent": psutil.virtual_memory().percent,
            "used": psutil.virtual_memory().used,
            "free": psutil.virtual_memory().free,
            "active": psutil.virtual_memory().active,
            "inactive": psutil.virtual_memory().inactive,
            "buffers": psutil.virtual_memory().buffers,
            "cached": psutil.virtual_memory().cached,
            "shared": psutil.virtual_memory().shared,
            "slab": psutil.virtual_memory().slab
        },
        'boot_time': psutil.boot_time(),
        'updated_at': str(datetime.now(tzutc()))
    }
    db.save_gw_stats(id, stats)


def monitor_uptime(db, id):
    updated_at = UpdatedAtSchema().load(UpdatedAtModel().to_dict())
    db.save_gw_uptime(id, updated_at)
