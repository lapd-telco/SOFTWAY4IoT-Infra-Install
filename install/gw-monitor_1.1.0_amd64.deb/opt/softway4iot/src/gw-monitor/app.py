import logging

from sw4iotdatabase.database import Sw4IotDatabase
from apscheduler.schedulers.blocking import BlockingScheduler
from jobs.status_monitor import monitor_gateway_stats
from jobs.status_monitor import monitor_uptime

logging.getLogger('apscheduler').setLevel(logging.ERROR)
logging.getLogger('sw4iot').setLevel(logging.INFO)
logging.getLogger('sw4iot_net_man').setLevel(logging.DEBUG)

FORMAT = '%(asctime)s - %(name)s - %(funcName)s - %(levelname)s - %(message)s'
logging.basicConfig(filename='/opt/softway4iot/logs/net-manager.log', filemode='a', format=FORMAT)
logger = logging.getLogger('NetManSW4IoT')
logger.setLevel(logging.INFO)


if __name__ == '__main__':
    db = Sw4IotDatabase(host='10.250.1.4')

    logger.info("Starting monitor...")

    with open("/opt/softway4iot/conf.softway4iot") as f:
        _, gw_id = f.readline().split('=')

    scheduler = BlockingScheduler(timezone="UTC")
    scheduler.add_job(monitor_uptime, 'interval', args=[db, gw_id], seconds=2, id=monitor_uptime.__name__,
                      replace_existing=True)
    scheduler.add_job(monitor_gateway_stats, 'interval', args=[db, gw_id], seconds=2, id=monitor_gateway_stats.__name__,
                      replace_existing=True)

    try:
        logger.info("Starting sw4iot-Agent scheduler jobs")
        scheduler.start()
    except (Exception, KeyboardInterrupt, SystemExit):
        logger.info("Exit sw4iot-Agent scheduler jobs")
        scheduler.remove_all_jobs()
        logger.info("All jobs have been removed")
