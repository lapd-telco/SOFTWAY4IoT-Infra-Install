import logging

from scapy.config import conf
from scapy.layers.dhcp import BOOTP, DHCP, DHCPRevOptions
from scapy.layers.inet import IP, UDP, TCP
from scapy.layers.l2 import Ether
from scapy.sendrecv import srp1, sendp
from scapy.utils import mac2str
from scapy.volatile import RandInt
import socket

conf.checkIPaddr = False

logger = logging.getLogger(__name__)
tcp_dev = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connected = False

def get_host_ip():
    return [(s.connect(('8.8.8.8', 53)), s.getsockname()[0], s.close()) for s in
            [socket.socket(socket.AF_INET, socket.SOCK_DGRAM)]][0][1]


def make_dhcp_request(device_mac, local_iface):
    """
    Make a DHCP Request to server and receive a IP address to device

    :param device_mac: mac address of device
    :param local_iface: interface
    :type device_mac: str
    :type local_iface: str
    """

    # build dhcp discover packet
    dhcp_discover = Ether(src=device_mac, dst='ff:ff:ff:ff:ff:ff') \
                    / IP(src='0.0.0.0', dst='255.255.255.255') \
                    / UDP(dport=67, sport=68) \
                    / BOOTP(chaddr=mac2str(device_mac), xid=RandInt()) \
                    / DHCP(options=[('message-type', 'discover'),
                                    ("param_req_list",
                                     DHCPRevOptions["subnet_mask"][0],
                                     DHCPRevOptions["router"][0],
                                     DHCPRevOptions["name_server"][0],
                                     DHCPRevOptions["domain"][0],
                                     DHCPRevOptions["lease_time"][0]),
                                    DHCPRevOptions["renewal_time"][0],
                                    'end'])
    # send dhcp discover packet
    dhcp_offer = srp1(dhcp_discover, iface=local_iface, timeout=5)
    if not dhcp_offer:
        logger.info("DHCP offer error of deive {}".format(device_mac))
        return

    # Set dhcp request fields
    myip = dhcp_offer[BOOTP].yiaddr
    sip = dhcp_offer[BOOTP].siaddr
    xid = dhcp_offer[BOOTP].xid
    # build dhcp request packet
    dhcp_request = Ether(src=device_mac, dst="ff:ff:ff:ff:ff:ff") \
                   / IP(src="0.0.0.0", dst="255.255.255.255") \
                   / UDP(sport=68, dport=67) / BOOTP(chaddr=mac2str(device_mac), xid=xid) \
                   / DHCP(options=[('message-type', 'request'),
                                   ("server_id", sip),
                                   ("requested_addr", myip),
                                   ("param_req_list",
                                    DHCPRevOptions["subnet_mask"][0],
                                    DHCPRevOptions["router"][0],
                                    DHCPRevOptions["name_server"][0],
                                    DHCPRevOptions["domain"][0],
                                    DHCPRevOptions["lease_time"][0]),
                                   DHCPRevOptions["renewal_time"][0],
                                   "end"])
    # call dhcp request & wait receive the ip_address, until timeout
    dhcp_ack = srp1(dhcp_request, iface=local_iface, timeout=5)
    dhcp_type = next(
        opt[1] for opt in dhcp_ack[DHCP].options if isinstance(opt, tuple) and opt[0] == 'message-type')
    if dhcp_type is not 5:
        return None
    else:
        return myip


def send_data_to_app(db, device_mac, protocol, data, localiface):
    simple_dev = db.get_device(device_mac)
    if simple_dev and db.get_slice(simple_dev.slice):
        device = db.get_slice_device(simple_dev.slice, simple_dev.id, all=True)
        if not (device or device.net):
            logger.info("Device {} slice {} need to be network configuration".format(simple_dev.id, simple_dev.slice))

        if not device.enabled:
            logger.info("Device {} of slice {} is not enabled".format(simple_dev.id, simple_dev.slice))

        # get slice connection information (bridge linux)
        # slice_conn = db.get_slice_conn(simple_dev.slice)
        # # set the port to send the package
        # localiface = slice_conn.br_slice

        # get slice tech info
        if device and device.enabled:
            # get slice app
            app = db.get_slice_app(simple_dev.slice, device.app_id)
            if not app:
                logger.info(
                    "Not exists a application on slice {} to send the data of this device {}".format(simple_dev.slice,
                                                                                                     device_mac))
                return
            app.status = db.get_slice_app_status(simple_dev.slice, device.app_id)
            if app and app.status.pod_ip and app.status.mac:
                # send application
                logger.info("Send package data {} of device {} to application {}".format(data, device_mac,
                                                                                         app.status.pod_ip))
                dst_mac = app.status.mac[5:-2]
                dst_ip = app.status.pod_ip[5:-5]
                dest = (dst_ip, 9980)
                global connected
                if not connected:
                    connected = True
                    tcp_dev.connect(dest)
                tcp_dev.send(data.encode())
                #tcp_dev.close()

def get_gw_conf_file():
    f = open('/opt/softway4iot/conf.softway4iot', 'r')
    if f.mode == 'r':
        fcontent = str(f.readline())
        ID_PREFIX = "NUMBER_GATEWAY_CONTROLL="
        fcontent = fcontent.replace(ID_PREFIX,'')
        GW_ID = int(fcontent)
        fcontent = str(f.readline())
        ETH_PREFIX = "PHYSICAL_NETWORK_INTERFACE="
        fcontent = fcontent.replace(ETH_PREFIX,'')
        GW_ETH = str(fcontent)
        f.close()
        return GW_ID,GW_ETH.rstrip()