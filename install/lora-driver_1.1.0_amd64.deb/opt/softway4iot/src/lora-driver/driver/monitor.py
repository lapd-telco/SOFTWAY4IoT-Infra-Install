import logging
import threading

from sw4iotdatabase import database
from sw4iotdatabase.models import InterfaceModel
from driver import daemon_iface_driver
from driver.utils import get_gw_conf_file

logger = logging.getLogger(__name__)


def driver_monitor(driver_func, protocol):
    """
    Monitor all instances of the LoRa driver function, starting and stopping the drivers when a new interface is
    added or removed.

    :param driver_func: LoRa driver function
    """
    db = database.Sw4IotDatabase()
    GW_ID, GW_ETH = get_gw_conf_file()
    interfaces = db.get_gw_interfaces(GW_ID, protocol)

    # stop the driver's of the removed interfaces
    threads_running = [t.name for t in threading.enumerate() if "{}_".format(protocol) in t.name]
    driver_to_remove = set(threads_running) - set(["{}_{}".format(protocol, i.name) for i in interfaces])
    for driver in driver_to_remove:
        daemon_iface_driver["{}_{}".format(protocol, driver)] = False

    # start driver to all interfaces
    for iface in interfaces:  # type: InterfaceModel
        threads_running = [t.name for t in threading.enumerate() if "{}_".format(protocol) in t.name]
        if "{}_{}".format(protocol, iface.name) not in threads_running:
            daemon_iface_driver["{}_{}".format(protocol, iface.name)] = True
            t = threading.Thread(name="{}_{}".format(protocol, iface.name), target=driver_func, args=(iface,))
            t.start()
