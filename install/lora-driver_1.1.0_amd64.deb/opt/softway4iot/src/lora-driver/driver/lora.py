import serial
from scapy.all import *
from driver import daemon_iface_driver
from scapy.layers.inet import IP, TCP
from scapy.layers.l2 import Ether
from sw4iotdatabase import database
from sw4iotdatabase.models import InterfaceModel
from sw4iotdatabase.schemas import InterfaceSchema
from driver.utils import send_data_to_app, get_gw_conf_file, get_host_ip
import time
import threading
db = database.Sw4IotDatabase()

logger = logging.getLogger(__name__)
sem = threading.Semaphore()
BAUD_RATE = 115200
PORT = ''
GW_ID, local_iface = get_gw_conf_file()
local_iface_mac = get_if_hwaddr(local_iface)

tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
simple_dev = db.get_device('fc:4d:d4:33:2f:01')
device = db.get_slice_device(str(simple_dev.slice),str(simple_dev.id))
dest = '10.249.'+device.gateways[0]+'.1'
orig = (dest, 9990)
tcp.bind(orig)
tcp.listen(1)

def lora_driver(interface):
    ser = serial.Serial(interface.device, BAUD_RATE, timeout=0)
    """
    LoRa driver
    :param interface: LoRa interface
    :type interface: InterfaceModel
    """
    def thr1():

        # Serial port of usb interface (default = /dev/ttyACM0)

        # the baud rate in tests only work's with 115200
        logger.info("LoRaDriver to inteface {}".format(PORT))
        while daemon_iface_driver["{}_{}".format(InterfaceModel.type.LORA, interface.name)]:
            try:
                # open serial
                sem.acquire()
                # get data GW:MAC:data...
                data = ser.readline()  # read a '\n' terminated line
                # close serial
                sem.release()
                time.sleep(0.1)
                data = data.decode("utf-8")
                if GW_ID + ':' not in data:
                    continue
                #build the custom mac
                mac_id = data[3:5]
                device_mac = "fc:4d:d4:33:2f:" + mac_id  # mac
                data = data[6:].replace('\r', '').replace('\n', '')
                # if len(data) == 0:
                #     logger.error("No data received of device {}".format(device_mac))
                #     continue
                logger.debug("Received data {} of device {}".format(data, device_mac))

                    # send_data = threading.Thread(target=send_data_thread, args=(db, device_mac, data))
                    # send_data.start()
                logger.info("Start send data {} of device {}".format(data, device_mac,local_iface))
                send_data_to_app(db,device_mac,InterfaceModel.type.LORA, data, local_iface)
                print('Send data:',data)
            except Exception as e:
                logger.error(e)

    def thr2():
        try:
            while True:
                con, cliente = tcp.accept()
                msg = con.recv(1024)
                if not msg: continue
                sem.acquire()
                print('Dados recebidos da deviceApp:', msg.decode("utf-8"))
                ser.write(msg)  # Determinar estrutura do pacote
                sem.release()
                time.sleep(0.1)
            con.close()
        except Exception as e:
            logger.error(e)

    t = threading.Thread(target = thr1)
    t.start()
    t2 = threading.Thread(target = thr2)
    t2.start()
