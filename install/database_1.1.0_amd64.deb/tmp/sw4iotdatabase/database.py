import logging
import os

import etcd3
from marshmallow import INCLUDE

from cryptography.fernet import Fernet

from sw4iotdatabase.models import *
from sw4iotdatabase.schemas import SliceSchema, DeviceSchema, SecuritySchema, SliceNetSchema, InterfaceSchema, \
    GatewayInfoSchema, GatewaySchema, SliceConnectionSchema, DefaultNetConfigSchema, ActionSchema, StatusSchema, \
    WifiSchema, ZigbeeSchema, LoraSchema, SimpleDeviceSchema, NetDeviceSchema, AppStatusSchema, \
    UpdatedAtSchema, VirtualInterfaceSchema, NRFSchema, AppSchemaLoad, NewGatewaySchema, TokenGatewayInstallSchema, \
    UserSchema, RevokedTokenSchema

ETCD_PREFIX = '/sw4iot'

logger = logging.getLogger(__name__)


def decode_utf8(text):
    if type(text) is bytes:
        return text.decode('utf-8')
    return text


class Sw4IotDatabase:

    def __init__(self, host=os.environ.get('ETCD_SERVER', '10.250.1.4'), port=os.environ.get('ETCD_PORT', 2379)):
        self.etcd = etcd3.client(host, port)

    def save_default_net_config(self, config):
        """
        Save default network configuration

        :param config: Default network configuration
        :type config: DefaultNetConfigModel
        """
        logger.debug("Save default network configuration {}".format(config))
        self.etcd.put('{}/config/default_net'.format(ETCD_PREFIX), config.to_json())

    def get_default_net_config(self):
        """
        Get default network configuration

        :rtype: DefaultNetConfigModel
        """
        config = self.etcd.get('{}/config/default_net'.format(ETCD_PREFIX))[0]
        logger.debug("Get default network configuration")
        return DefaultNetConfigSchema().load(json.loads(decode_utf8(config)), unknown=INCLUDE) if config else None

    def get_gateways(self, all=False):
        """
        Get all gateways

        :param all: Get all relationships, if True, otherwise, no
        :type all: bool
        :return: List of gateways
        :rtype: list
        """
        gws = [GatewaySchema().load(json.loads(decode_utf8(gw[0]))) for gw in
               self.etcd.get_prefix('{}/gws'.format(ETCD_PREFIX))]
        if all:
            for gw in gws:
                gw.info = self.get_gw_info(gw.id)
        return gws

    def get_gateway(self, id):
        """
        Get gateway

        :param id: Gateway identifier
        :type id: str
        :rtype: GatewayModel
        :return: The gateway found, otherwise, None
        """
        data = self.etcd.get('{}/gws/{}'.format(ETCD_PREFIX, id))[0]
        logger.debug('get_gateway: {}'.format(data))
        gateway = GatewaySchema().load(json.loads(decode_utf8(data)), unknown=INCLUDE) if data else None
        if gateway:
            gateway.info = self.get_gw_info(id)
        return gateway

    def save_gateway(self, gateway):
        """
        Save gateway

        :param gateway: Gateway object
        :type gateway: GatewayModel
        """
        logger.debug("Save gateway {}".format(gateway))
        self.etcd.put('{}/gws/{}'.format(ETCD_PREFIX, gateway.id), gateway.to_json())

    def delete_gateway(self, id):
        """
        Delete gateway

        :param id: Gateway identifier
        :type id: str
        :rtype: bool
        """
        logger.debug("Delete gateway {}".format(id))
        return self.etcd.delete('{}/gws/{}'.format(ETCD_PREFIX, id))

    def get_slices(self, all=False):
        """
        Get all slices

        :param all: Get all relationships, if True, otherwise, no
        :rtype: list
        :return: List of all slices found
        """
        slices = [SliceSchema().load(json.loads(decode_utf8(s[0])), unknown=INCLUDE) for s in
                  self.etcd.get_prefix('{}/slices'.format(ETCD_PREFIX))]
        if all:
            for slice in slices:
                slice.vlan = self.get_slice_vlan(slice.id)
                slice.net = self.get_slice_net(slice.id)
                slice.enabled = self.get_slice_enabled(slice.id)
        return slices

    def get_slice(self, slice_id, all=False):
        """
        Get slice

        :param slice_id: Slice identifier
        :param all: Get all relationships, if True, otherwise, no
        :type slice_id: str
        :type all: bool
        :rtype: SliceModel
        """
        data = self.etcd.get('{}/slices/{}'.format(ETCD_PREFIX, slice_id))[0]
        logger.debug('Get slice {} object {}'.format(slice_id, data))
        slice = SliceSchema().load(json.loads(decode_utf8(data)), unknown=INCLUDE) if data else None
        if all:
            slice.enabled = self.get_slice_enabled(slice_id)
            slice.vlan = self.get_slice_vlan(slice_id)
            slice.net = self.get_slice_net(slice_id)
        return slice

    def save_slice(self, slice):
        """
        Save slice

        :param slice: Slice object
        :type slice: SliceModel
        """
        logger.debug("Save slice {} as {}".format(slice.id, slice))
        self.etcd.put('{}/slices/{}'.format(ETCD_PREFIX, slice.id), slice.to_json())

    def del_slice(self, id):
        """
        Delete slice

        :param id: Slice identifier
        :type id: str
        :rtype: bool
        """
        logger.debug("Delete slice {}".format(id))
        return self.etcd.delete_prefix('{}/slices/{}'.format(ETCD_PREFIX, id))

    def get_slice_net(self, slice_id):
        """
        Get slice

        :param slice_id: Slice identifier
        :type slice_id: str
        :return: Network information of slice
        :rtype: SliceNetModel
        """
        slice_net = self.etcd.get('{}/slice/{}/net'.format(ETCD_PREFIX, slice_id))[0]
        logger.debug('Get slice {} network information {}'.format(slice_id, slice_net))
        return SliceNetSchema().load(json.loads(decode_utf8(slice_net))) if slice_net else None

    def save_slice_net(self, slice_id, net):
        """
        Get slice

        :param slice_id: Slice identifier
        :param net: Network information of slice generated by the Contiv plugin
        :type slice_id: str
        :type net: SliceNetModel
        """
        logger.debug('Save slice {} network information {}'.format(slice_id, net))
        self.etcd.put('{}/slice/{}/net'.format(ETCD_PREFIX, slice_id), net.to_json())

    def get_slice_vlan(self, slice_id):
        """
        Get slice vlan

        :param slice_id: Slice identifier
        :type slice_id: str
        :return: Vlan number
        :rtype: int
        """
        vlan = self.etcd.get('{}/slice/{}/vlan'.format(ETCD_PREFIX, slice_id))[0]
        logger.debug('Get slice {} vlan {}'.format(slice_id, vlan))
        return json.loads(decode_utf8(vlan))['vlan'] if vlan else None

    def save_slice_vlan(self, slice_id, vlan):
        """
        Save slice vlan

        :param slice_id: Slice identifier
        :param vlan: Vlan number
        :type slice_id: str
        :type vlan: int
        """
        logger.debug('Save slice {} vlan {}'.format(slice_id, vlan))
        self.etcd.put('{}/slice/{}/vlan'.format(ETCD_PREFIX, slice_id), json.dumps({'vlan': vlan}))

    def save_slice_enabled(self, slice_id, enabled=True):
        """
        Save slice enabled

        :param slice_id: Slice identifier
        :param enabled: Status of slice
        :type slice_id: str
        :type enabled: bool
        """
        logger.debug('Save slice {} enabled {}'.format(slice_id, enabled))
        self.etcd.put('{}/slice/{}/enabled'.format(ETCD_PREFIX, slice_id), json.dumps({'enabled': enabled}))

    def get_slice_enabled(self, slice_id):
        """
        Get slice enabled

        :param slice_id: Slice identifier
        :type slice_id: str
        """
        enabled = self.etcd.get('{}/slice/{}/enabled'.format(ETCD_PREFIX, slice_id))[0]
        logger.debug('Get slice {} enabled {}'.format(slice_id, enabled))
        return json.loads(decode_utf8(enabled))['enabled'] if enabled else False

    def add_slice_gw(self, slice_id, gw_id):
        """
        Add a gateway on slice

        :param slice_id: slice identifier
        :param gw_id: gateway identifier
        :type slice_id: str
        :type gw_id: str
        """
        logger.debug("Add gateway {} on slice {}".format(gw_id, slice_id))
        self.etcd.put('{}/slice/{}/gws/{}'.format(ETCD_PREFIX, slice_id, gw_id), json.dumps({'id': gw_id}))

    def get_slice_gws(self, slice_id):
        """
        Get all gateways of slice

        :param slice_id: Slice identifier
        :type slice_id: str
        :return: Gateways list
        """
        logger.debug("Get all gateways of slice {}".format(slice_id))
        gws = [json.loads(decode_utf8(g[0])) for g in
               self.etcd.get_prefix('{}/slice/{}/gws'.format(ETCD_PREFIX, slice_id))]
        return [self.get_gateway(g['id']) for g in gws]

    def get_slice_gw(self, slice_id, gw_id):
        """
        Get a gateway of slice

        :param slice_id: Slice identifier
        :param gw_id: Gateway identifier
        :type slice_id: str
        :type gw_id: str
        :rtype: GatewayModel
        :return: The gateway
        """
        logger.debug("Get gateway {} of slice {}".format(gw_id, slice_id))
        gateway = self.etcd.get('{}/slice/{}/gws/{}'.format(ETCD_PREFIX, slice_id, gw_id))[0]
        return self.get_gateway(json.loads(decode_utf8(gateway))['id']) if gateway else None

    def del_slice_gw(self, slice_id, gw_id, all=False):
        """
        Delete a gateway of slice

        :param slice_id: Slice identifier
        :param gw_id: Gateway identifier
        :param all: Fetch all relationships, if True, otherwise, no
        """
        logger.debug("Delete gateway {} in slice {}".format(gw_id, slice_id))
        self.etcd.delete('{}/slice/{}/gws/{}'.format(ETCD_PREFIX, slice_id, gw_id))
        if all:
            self.etcd.delete_prefix('{}/slice/{}/gw/{}'.format(ETCD_PREFIX, slice_id, gw_id))

    def add_slice_tech(self, slice_id, tech, data):
        """
        Add a technology on slice

        :param slice_id: Slice identifier
        :param tech: Technology [lora, nrf, wifi or zigbee]
        :param data: Technology object
        :type slice_id: str
        :type tech: str
        :type data: TechModel
        """
        logger.debug("Add technology {} on slice {}".format(tech, slice_id))
        self.etcd.put('{}/slice/{}/tech/{}/info'.format(ETCD_PREFIX, slice_id, tech), data.to_json())

    def get_slice_tech(self, slice_id, protocol, all=False):
        """
        Get a technology of slice

        :param slice_id: Slice identifier
        :param protocol: Technology [lora, nrf, wifi or zigbee]
        :param all: Get all relationships, if True, otherwise, no
        :type slice_id: str
        :type protocol: str
        :type all: bool
        :rtype: TechModel
        """
        logger.debug("Get technology {} of slice {}".format(protocol, slice_id))
        if protocol == InterfaceModel.type.LORA:
            schema = LoraSchema
        elif protocol == InterfaceModel.type.WIFI:
            schema = WifiSchema
        elif protocol == InterfaceModel.type.ZIGBEE:
            schema = ZigbeeSchema
        elif protocol == InterfaceModel.type.NRF:
            schema = NRFSchema
        else:
            return None

        slice_tech = self.etcd.get('{}/slice/{}/tech/{}/info'.format(ETCD_PREFIX, slice_id, protocol))[0]
        tech = schema().load(json.loads(decode_utf8(slice_tech)), unknown=INCLUDE) if slice_tech else None
        if tech and all:
            if protocol == InterfaceModel.type.WIFI:
                status = {}
                for gw in tech.gateways:
                    tech_status = self.get_gw_slice_tech_status(gw, slice_id, InterfaceModel.type.WIFI)
                    tech_status = tech_status.to_dict() if tech_status else None
                    status[gw] = tech_status if tech_status else None
                tech.statuses = status if status else None
        return tech

    def del_slice_tech(self, slice_id, protocol):
        """
        Delete slice technology

        :param slice_id: Slice identifier
        :param protocol: Technology [lora, nrf, wifi or zigbee]
        :type slice_id: str
        :type protocol: str
        :rtype: bool
        """
        logger.debug("Delete technology {} of slice {} ".format(protocol, slice_id))
        return self.etcd.delete('{}/slice/{}/tech/{}/info'.format(ETCD_PREFIX, slice_id, protocol))

    def save_slice_device(self, slice_id, device):
        """
        Save device

        :param slice_id: Slice identifier
        :param device: Device object
        :type slice_id: str
        :type device: DeviceModel
        """
        logger.debug("Save device {}".format(device))
        self.etcd.put('{}/slice/{}/devices/{}'.format(ETCD_PREFIX, slice_id, str(device.id).lower()), device.to_json())

    def get_slice_device(self, slice_id, device_id, all=False):
        """
        Get slice device

        :param slice_id: Slice identifier
        :param device_id: Device identifier
        :param all: Fetch all relationships, if True, otherwise, no
        :type slice_id: str
        :type device_id: str
        :rtype: DeviceModel
        """
        device_id = device_id.lower()
        logger.debug("get device {} of slice {}".format(device_id, slice_id))
        dev = self.etcd.get('{}/slice/{}/devices/{}'.format(ETCD_PREFIX, slice_id, device_id))[0]
        device = DeviceSchema().load(json.loads(decode_utf8(dev)), unknown=INCLUDE) if dev else None
        if device and all:
            device.net = self.get_slice_device_net(slice_id, device_id)
            device.action = self.get_device_action(device_id)
        return device

    def get_slice_devices(self, slice_id, all=False):
        """
        Get all devices of slice

        :param slice_id: Slice identifier
        :param all: Fetch all relationships, if True, otherwise, no
        :type slice_id: str
        :type all: bool
        :return: Device list
        """
        logger.debug("Get all devices of slice {}".format(slice_id))
        devices = [DeviceSchema().load(json.loads(decode_utf8(s[0])), unknown=INCLUDE) for s in
                   self.etcd.get_prefix('{}/slice/{}/devices'.format(ETCD_PREFIX, slice_id))]
        if devices and all:
            for device in devices:
                device.net = self.get_slice_device_net(slice_id, device.id)
                device.host = self.get_slice_device_host(slice_id, device.id)
                device.action = self.get_device_action(device.id)
        return devices

    def delete_slice_device(self, slice_id, device_id, all=False):
        """
        Delete slice device

        :param slice_id: Slice identifier
        :param device_id: Device identifier
        :param all: Delete all relationships, if True, otherwise, no
        :type slice_id: str
        :type device_id: str
        :type all: bool
        """
        device_id = device_id.lower()
        logger.debug("Delete device {} of slice {}".format(device_id, slice))
        if all:
            self.delete_slice_device_net(slice_id, device_id)
            self.delete_device_action(device_id)

        return self.etcd.delete('{}/slice/{}/devices/{}'.format(ETCD_PREFIX, slice_id, device_id))

    def save_device_action(self, device_id, action):
        """
        Save device action

        :param device_id: Device identifier
        :param action: Action to be taken
        :type device_id: str
        :type action: ActionModel
        """
        device_id = device_id.lower()
        logger.debug("Save device {} action {}".format(device_id, action.to_json()))
        self.etcd.put('{}/device/{}/action'.format(ETCD_PREFIX, device_id), action.to_json())

    def get_device_action(self, device_id):
        """
        Get device action

        :param device_id: Device identifier
        :type device_id: str
        :rtype: ActionModel
        """
        device_id = device_id.lower()
        logger.debug("Get device {} action".format(device_id))
        action = self.etcd.get('{}/device/{}/action'.format(ETCD_PREFIX, device_id))[0]
        return ActionSchema().load(json.loads(decode_utf8(action)), unknown=INCLUDE) if action else None

    def delete_device_action(self, device_id):
        """
        Delete device action

        :param device_id: Device identifier
        :type device_id: str
        :rtype: bool
        """
        device_id = device_id.lower()
        logger.debug("Delete device {} action".format(device_id))
        return self.etcd.delete('{}/device/{}/action'.format(ETCD_PREFIX, device_id))

    def save_slice_security(self, slice_id, sec_id, security):
        """
        Save slice security NAT

        :param slice_id: Slice identifier
        :param sec_id: Security ['nat']
        :param security: Security object
        :type slice_id: str
        :type sec_id: SecurityTypeEnum
        :type security: SecurityModel
        """
        logger.debug("save slice {} security {}".format(slice_id, sec_id))
        self.etcd.put('{}/slice/{}/security/{}'.format(ETCD_PREFIX, slice_id, sec_id), security.to_json())

    def get_slice_security(self, slice_id, sec_id):
        """
        Get slice security NAT

        :param slice_id: slice identifier
        :param sec_id: Security ['nat']
        :type slice_id: int
        :type sec_id: SecurityTypeEnum
        :rtype: SecurityModel
        """
        logger.debug("Get slice {} security {}".format(slice_id, sec_id))
        security = self.etcd.get('{}/slice/{}/security/{}'.format(ETCD_PREFIX, slice_id, sec_id))[0]
        return SecuritySchema().load(json.loads(decode_utf8(security)), unknown=INCLUDE) if security else None

    def get_last_vlan(self):
        """
        Get last vlan added to the slices

        :return Last vlan
        :rtype: int
        """
        last_vlan = self.etcd.get('{}/data/last_vlan'.format(ETCD_PREFIX))[0]
        logger.debug('Get last vlan added to the slices: {}'.format(last_vlan))
        return json.loads(decode_utf8(last_vlan))['vlan'] if last_vlan else None

    def save_last_vlan(self, vlan):
        """
        Save last vlan

        :param vlan: Vlan number
        :type vlan: int
        """
        logger.debug('Save last vlan {}'.format(vlan))
        self.etcd.put('{}/data/last_vlan'.format(ETCD_PREFIX), json.dumps({'vlan': vlan}))

    def save_vlan(self, vlan):
        """
        Save vlan added to the slice

        :param vlan: Vlan object
        :type vlan: VlanModel
        """
        logger.debug('save vlan {}'.format(vlan))
        self.etcd.put('{}/data/vlans/{}'.format(ETCD_PREFIX, vlan.vlan), vlan.to_json())

    def get_vlan(self, vlan_id):
        """
        Get vlan

        :param vlan_id: Vlan number
        :type vlan_id: int
        :rtype: VlanModel
        :return: The vlan selected
        """
        vlan = self.etcd.get('{}/data/vlans/{}'.format(ETCD_PREFIX, vlan_id))[0]
        logger.debug('Get vlan {}'.format(vlan))
        return VlanModel.to_dict(json.loads(decode_utf8(vlan))) if vlan else None

    def get_release_slices(self):
        """
        Get all slices to be released

        :rtype: list
        :return: list of slices identifier
        """
        return [json.loads(decode_utf8(s[0]))['slice'] for s in
                self.etcd.get_prefix('{}/release/slices'.format(ETCD_PREFIX))]

    def add_release_slice(self, slice_id):
        """
        Add slice to be released

        :param slice_id: Slice identifier
        :type slice_id: str
        """
        logger.debug('Release slice {}'.format(slice_id))
        self.etcd.put('{}/release/slices/{}'.format(ETCD_PREFIX, slice_id), json.dumps({'slice': slice_id}))

    def delete_release_slice(self, slice_id, all=False):
        """
        Delete slice to be released

        :param slice_id: slice identifier
        :param all: Delete all relationships, if True, otherwise, no
        :type slice_id: str
        :type all: bool
        """
        logger.debug('Delete release slice {}'.format(slice_id))
        self.etcd.delete('{}/release/slices/{}'.format(ETCD_PREFIX, slice_id))
        if all:
            self.etcd.delete_prefix('{}/slices/{}'.format(ETCD_PREFIX, slice_id))
            self.etcd.delete_prefix('{}/slice/{}'.format(ETCD_PREFIX, slice_id))

    def add_gw_slice(self, gw_id, slice_id):
        """
        Add a slice on the gateway

        :param gw_id: Gateway identifier
        :param slice_id: Slice identifier
        :type gw_id: str
        :type slice_id: str
        """
        logger.debug("Add slice {} in gateway {}".format(slice_id, gw_id))
        self.etcd.put('{}/gw/{}/slices/{}'.format(ETCD_PREFIX, gw_id, slice_id), json.dumps({'id': slice_id}))

    def get_gw_slices(self, gw_id):
        """
        Get all slices of gateway

        :param gw_id: Gateway identifier
        :type gw_id: str
        :return: Slice list
        """
        logger.debug("Get all slices of gateway {}".format(gw_id))
        return [json.loads(decode_utf8(s[0]))['id'] for s in
                self.etcd.get_prefix('{}/gw/{}/slices'.format(ETCD_PREFIX, gw_id))]

    def delete_gw_slice(self, gw_id, slice_id, all=False):
        """
        Delete a slice of gateway

        :param gw_id: Gateway identifier
        :param slice_id: Slice identifier
        :param all: Delete all relationships, if True, otherwise, no
        :type gw_id: str
        :type slice_id: str
        :type all: bool
        """
        logger.debug("Delete slice {} of gateway {}".format(slice_id, gw_id))
        self.etcd.delete('{}/gw/{}/slices/{}'.format(ETCD_PREFIX, gw_id, slice_id))
        if all:
            self.etcd.delete_prefix('{}/gw/{}/slice/{}'.format(ETCD_PREFIX, gw_id, slice_id))

    def save_gw_interface(self, gw_id, protocol, interface):
        """
        Save a interface of protocol

        :param gw_id: Gateway identifier
        :param protocol: Technology [lora, nrf, wifi or zigbee]
        :param interface: Interface object
        :type gw_id: str
        :type protocol: str
        :type interface: InterfaceModel
        """
        logger.debug("Save {} interface {} of gateway {}".format(protocol, interface.name, gw_id))
        self.etcd.put('{}/gw/{}/net/{}/ifaces/{}'.format(ETCD_PREFIX, gw_id, protocol, interface.name),
                      interface.to_json())

    def get_gw_interfaces(self, gw_id, protocol):
        """
        Get all interfaces of protocol

        :param gw_id: gateway identifier
        :param protocol: technology [lora, nrf, wifi or zigbee]
        :type gw_id: str
        :type protocol: TechnologyEnum
        :rtype: list
        :return: List of Interface
        """
        logger.debug("Get all {} interfaces of gateway {}".format(protocol, gw_id))
        interfaces = self.etcd.get_prefix('{}/gw/{}/net/{}/ifaces'.format(ETCD_PREFIX, gw_id, protocol))
        return [InterfaceSchema().load(json.loads(decode_utf8(iface[0])), unknown=INCLUDE) for iface in interfaces]

    def get_gw_interface(self, gw_id, protocol, iface_name):
        """
        Get a interface on slice

        :param gw_id: Gateway identifier
        :param protocol: Technology [lora, nrf, wifi or zigbee]
        :param iface_name: Interface name
        :type gw_id: str
        :type protocol: str
        :type iface_name: str
        :rtype: InterfaceModel
        """
        interface = self.etcd.get('{}/gw/{}/net/{}/ifaces/{}'.format(ETCD_PREFIX, gw_id, protocol, iface_name))[0]
        logger.debug("Get a {} interface of gateway {}".format(protocol, gw_id))
        return InterfaceSchema().load(json.loads(decode_utf8(interface))) if interface else None

    def delete_gw_interface(self, gw_id, protocol, iface_name):
        """
        Delete a interface of protocol

        :param gw_id: Gateway identifier
        :param protocol: Technology [lora, nrf, wifi or zigbee]
        :param interface: Interface name
        :type gw_id: str
        :type protocol: TechnologyEnum
        :type iface_name: str
        """
        logger.debug("Delete interface {} {} of gateway {}".format(protocol, iface_name, gw_id))
        self.etcd.delete('{}/gw/{}/net/{}/ifaces/{}'.format(ETCD_PREFIX, gw_id, protocol, iface_name))

    def save_gw_info(self, gw_id, info):
        """
        Save gateway information

        :param gw_id: Gateway identifier
        :param info: Gateway information
        :type gw_id: str
        :type info: GatewayInfoModel
        """
        logger.debug("Save gateway {} information {}".format(gw_id, info))
        self.etcd.put('{}/gw/{}/info'.format(ETCD_PREFIX, gw_id), info.to_json())

    def get_gw_info(self, gw_id):
        """
        Get gateway information

        :param gw_id: gateway identifier
        :type gw_id: str
        :rtype: GatewayInfoModel
        """
        gw_info = self.etcd.get('{}/gw/{}/info'.format(ETCD_PREFIX, gw_id))[0]
        logger.debug("get gateway {} information {}".format(gw_id, gw_info))
        return GatewayInfoSchema().load(json.loads(decode_utf8(gw_info))) if gw_info else None

    def save_gw_stats(self, gw_id, stats):
        """
        Save gateway stats

        :param gw_id: Gateway identifier
        :param stats: Stats of gateway
        :type gw_id: str
        :type stats: dict
        """
        logger.debug("Update gateway {} stats {}".format(gw_id, stats))
        self.etcd.put('{}/gw/{}/stats'.format(ETCD_PREFIX, gw_id), json.dumps(stats))

    def get_gw_stats(self, gw_id):
        """
        Get gateway stats

        :param gw_id: Gateway identifier
        :type gw_id: str
        :rtype: dict
        """
        gw_stats = self.etcd.get('{}/gw/{}/stats'.format(ETCD_PREFIX, gw_id))[0]
        logger.debug("Get gateway {} stats {}".format(gw_id, gw_stats))
        return json.loads(decode_utf8(gw_stats)) if gw_stats else None

    def save_gw_uptime(self, gw_id, update_at):
        """
        Save gateway uptime

        :param gw_id: Gateway identifier
        :param update_at: UpdatedAt object
        :type update_at: UpdatedAtModel
        """
        logger.debug("Update gateway {} uptime {}".format(gw_id, update_at))
        self.etcd.put('{}/gw/{}/uptime'.format(ETCD_PREFIX, gw_id), update_at.to_json())

    def get_gw_uptime(self, gw_id):
        """
        Get gateway stats

        :param gw_id: Gateway identifier
        :type gw_id: str
        :rtype: UpdatedAtModel
        """
        gw_uptime = self.etcd.get('{}/gw/{}/uptime'.format(ETCD_PREFIX, gw_id))[0]
        logger.debug("Get gateway {} uptime {}".format(gw_id, gw_uptime))
        return UpdatedAtSchema().load(json.loads(decode_utf8(gw_uptime))) if gw_uptime else None

    def save_slice_conn(self, slice_id, conn):
        """
        Save slice connection

        :param slice_id: Slice identifier
        :param conn: Slice connection object
        :type slice_id: str
        :type conn: SliceConnectionModel
        """
        logger.debug("Save slice {} connection {}".format(slice_id, conn))
        self.etcd.put('{}/slice/{}/conn'.format(ETCD_PREFIX, slice_id), conn.to_json())

    def get_slice_conn(self, slice_id):
        """
        Get slice connection

        :param slice_id: slice identifier
        :type slice_id: str
        :rtype: SliceConnectionModel
        """
        conn = self.etcd.get('{}/slice/{}/conn'.format(ETCD_PREFIX, slice_id))[0]
        logger.debug("Get slice {} connection {}".format(slice_id, conn))
        return SliceConnectionSchema().load(json.loads(decode_utf8(conn)), unknown=INCLUDE) if conn else None

    def save_gw_slice_action(self, gw_id, slice_id, action):
        """
        Add gateway slice action

        :param gw_id: Gateway identifier
        :param slice_id: Slice identifier
        :param action: Action to be taken on slice
        :type gw_id: str
        :type slice_id: str
        :type action: ActionModel
        """
        logger.debug("Save slice {} action {} on gateway {}".format(slice_id, action.to_json(), gw_id))
        self.etcd.put('{}/gw/{}/slice/{}/action'.format(ETCD_PREFIX, gw_id, slice_id), action.to_json())

    def get_gw_slice_action(self, gw_id, slice_id):
        """
        Get gateway slice action

        :param gw_id: Gateway identifier
        :param slice_id: Slice identifier
        :type gw_id: str
        :type slice_id: str
        :rtype: ActionModel
        """
        action = self.etcd.get('{}/gw/{}/slice/{}/action'.format(ETCD_PREFIX, gw_id, slice_id))[0]
        logger.debug("Get slice {} action on gateway {}".format(slice_id, gw_id))
        return ActionSchema().load(json.loads(decode_utf8(action)), unknown=INCLUDE) if action else None

    def del_gw_slice_action(self, gw_id, slice_id):
        """
        Delete gateway slice action

        :param gw_id: Gateway identifier
        :param slice_id: Slice identifier
        :type gw_id: str
        :type slice_id: str
        :rtype: bool
        """
        logger.debug("Delete slice {} action on gateway {}".format(slice_id, gw_id))
        return self.etcd.delete('{}/gw/{}/slice/{}/action'.format(ETCD_PREFIX, gw_id, slice_id))

    def save_gw_slice_status(self, gw_id, slice_id, status):
        """
        Add gateway slice status

        :param gw_id: Gateway identifier
        :param slice_id: Slice identifier
        :param status: Status of slice in gateway
        :type gw_id: str
        :type slice_id: str
        :type status: StatusModel
        """
        logger.debug("Save slice {} status {} on gateway {}".format(slice_id, status.to_json(), gw_id))
        self.etcd.put('{}/gw/{}/slice/{}/status'.format(ETCD_PREFIX, gw_id, slice_id), status.to_json())

    def get_gw_slice_status(self, gw_id, slice_id):
        """
        Get gateway slice status

        :param gw_id: Gateway identifier
        :param slice_id: Slice identifier
        :type gw_id: str
        :type slice_id: str
        :rtype: StatusModel
        """
        status = self.etcd.get('{}/gw/{}/slice/{}/status'.format(ETCD_PREFIX, gw_id, slice_id))[0]
        logger.debug("Get slice {} status on gateway {}".format(slice_id, gw_id))
        return StatusSchema().load(json.loads(decode_utf8(status)), unknown=INCLUDE) if status else None

    def delete_gw_slice_status(self, gw_id, slice_id):
        """
        Add gateway slice status

        :param gw_id: Gateway identifier
        :param slice_id: Slice identifier
        :type gw_id: str
        :type slice_id: str
        :rtype: bool
        """
        logger.debug("Delete slice {} status on gateway {}".format(slice_id, gw_id))
        return self.etcd.delete('{}/gw/{}/slice/{}/status'.format(ETCD_PREFIX, gw_id, slice_id))

    def get_gw_slice_released(self, gw_id, slice_id):
        """
        Get gateway slice released state

        :param gw_id: Gateway identifier
        :param slice_id: Slice identifier
        :type gw_id: str
        :type slice_id: str
        :rtype: bool
        """
        released = self.etcd.get('{}/gw/{}/slice/{}/released'.format(ETCD_PREFIX, gw_id, slice_id))[0]
        logger.debug("Get slices released {}".format(released))
        return json.loads(decode_utf8(released))['released'] if released else None

    def save_gw_slice_released(self, gw_id, slice_id, released):
        """
        Add gateway slice to be released

        :param gw_id: Gateway identifier
        :param released: Release state
        :param slice_id: slice identifier
        :type gw_id: str
        :type slice_id: str
        :type released: bool
        """
        logger.debug('Gateway {} slice {} released {}'.format(gw_id, slice_id, released))
        self.etcd.put('{}/gw/{}/slice/{}/released'.format(ETCD_PREFIX, gw_id, slice_id),
                      json.dumps({'released': released}))

    def delete_gw_slice_released(self, gw_id, slice_id):
        """
        Delete gateway slice release state

        :param gw_id: Gateway identifier
        :param slice_id: slice identifier
        :type gw_id: str
        :type slice_id: str
        :rtype: bool
        """
        logger.debug('Delete release gw {} slice {}'.format(gw_id, slice_id))
        return self.etcd.delete('{}/gw/{}/slice/{}/released'.format(ETCD_PREFIX, gw_id, slice_id))

    def save_device(self, device_id, slice_id):
        """
        Save device

        :param device_id: Device identifier
        :param slice_id: Slice identifier
        :type device_id: str
        :type slice_id: str
        """
        logger.debug("Save device {} on slice {}".format(slice_id, device_id))
        simple_device = SimpleDeviceSchema().load({"id": device_id, "slice": slice_id})
        self.etcd.put('{}/devices/{}'.format(ETCD_PREFIX, device_id), simple_device.to_json())

    def get_device(self, device_id):
        """
        Get device

        :param device_id: device identifier
        :type device_id: str
        :rtype: SimpleDeviceModel
        """
        device_id = device_id.lower()
        logger.debug("Get device {}".format(device_id))
        device = self.etcd.get('{}/devices/{}'.format(ETCD_PREFIX, device_id))[0]
        return SimpleDeviceSchema().load(json.loads(decode_utf8(device)), unknown=INCLUDE) if device else None

    def get_devices(self):
        """
        Get all devices

        :rtype: list
        :return: SimpleDevice list
        """
        logger.debug("Get all devices")
        return [SimpleDeviceSchema().load(json.loads(decode_utf8(device[0])), unknown=INCLUDE) for device in
                self.etcd.get_prefix('{}/devices'.format(ETCD_PREFIX))]

    def delete_device(self, id, all=False):
        """
        Delete device

        :param id: Device identifier
        :param all: Delete all relationships, if True, otherwise, no
        :type id: str
        :type all: bool
        :rtype: bool
        """
        id = id.lower()
        logger.debug("delete device {}".format(id))
        if all:
            self.delete_device_action(id)
        return self.etcd.delete('{}/devices/{}'.format(ETCD_PREFIX, id))

    def save_slice_device_net(self, slice_id, device_id, net):
        """
        Save slice device network information

        :param slice_id: Slice identifier
        :param device_id: Device identifier
        :param net: Device network information
        :type slice_id: str
        :type device_id: str
        :type net: NetDeviceModel
        """
        logger.debug("Save slice {} device {} network {}".format(slice_id, device_id, net.to_json()))
        self.etcd.put('{}/slice/{}/device/{}/net'.format(ETCD_PREFIX, slice_id, device_id), net.to_json())

    def get_slice_device_net(self, slice_id, device_id):
        """
        Get device network information

        :param slice_id: Slice identifier
        :param device_id: Device identifier
        :type slice_id: str
        :type device_id: str
        :rtype: NetDeviceModel
        """
        logger.debug("Get slice {} device {} network information".format(slice_id, device_id))
        net_device = self.etcd.get('{}/slice/{}/device/{}/net'.format(ETCD_PREFIX, slice_id, device_id))[0]
        return NetDeviceSchema().load(json.loads(decode_utf8(net_device)), unknown=INCLUDE) if net_device else None

    def delete_slice_device_net(self, slice_id, device_id):
        """
        Delete device network information

        :param slice_id: Slice identifier
        :param device_id: Device identifier
        :type slice_id: str
        :type device_id: str
        """
        logger.debug("delete slice {} device {} network information".format(slice_id, device_id))
        return self.etcd.delete('{}/slice/{}/device/{}/net'.format(ETCD_PREFIX, slice_id, device_id))

    def save_slice_device_host(self, slice_id, device_id, host):
        """
        Save device host

        :param slice_id: Slice identifier
        :param device_id: Device identifier
        :param host: Device network information
        :type slice_id: str
        :type device_id: str
        :type host: str
        """
        logger.debug("save slice {} device {} host: {}".format(slice_id, device_id, host))
        self.etcd.put('{}/slice/{}/device/{}/host'.format(ETCD_PREFIX, slice_id, device_id), json.dumps(host))

    def get_slice_device_host(self, slice_id, device_id):
        """
        Get device host

        :param slice_id: Slice identifier
        :param device_id: Device identifier
        :type slice_id: str
        :type device_id: str
        :rtype: NetDeviceModel
        """
        logger.debug("Get slice {} device {} host".format(slice_id, device_id))
        device_host = self.etcd.get('{}/slice/{}/device/{}/host'.format(ETCD_PREFIX, slice_id, device_id))[0]
        return json.loads(decode_utf8(device_host)) if device_host else None

    def save_slice_app(self, slice_id, app):
        """
        Save slice application

        :param slice_id: Slice identifier
        :param app: Application object
        :type slice_id: str
        :type app: AppModel
        """
        logger.debug('Save slice {} application {}'.format(slice_id, app.to_dict()))
        self.etcd.put('{}/slice/{}/apps/{}'.format(ETCD_PREFIX, slice_id, app.id), json.dumps(app.id))
        self.etcd.put('{}/slice/{}/app/{}/info'.format(ETCD_PREFIX, slice_id, app.id), app.to_json())

    def delete_slice_app(self, slice_id, app_id):
        """
        Delete slice application

        :param slice_id: Slice identifier
        :param app_id: Application identifier
        :type slice_id: str
        :type app_id: str
        """
        logger.debug('delete slice {} application {}'.format(slice_id, app_id))
        self.etcd.delete('{}/slice/{}/apps/{}'.format(ETCD_PREFIX, slice_id, app_id))
        self.etcd.delete_prefix('{}/slice/{}/app/{}'.format(ETCD_PREFIX, slice_id, app_id))

    def get_slice_app(self, slice_id, app_id):
        """
        Get slice application

        :param slice_id: Slice identifier
        :param app_id: Application identifier
        :type slice_id: str
        :type app_id: str
        :rtype: AppModel
        """
        logger.debug("Get slice {} application {}".format(slice_id, app_id))
        app = self.etcd.get('{}/slice/{}/app/{}/info'.format(ETCD_PREFIX, slice_id, app_id))[0]
        return AppSchemaLoad().load(json.loads(decode_utf8(app)), unknown=INCLUDE) if app else None

    def get_slice_apps(self, slice_id):
        """
        Get all slice applications

        :param slice_id: Slice identifier
        :type slice_id: str
        :rtype: list
        :return: List of all slice applications
        """
        logger.debug("Get all slice {} applications".format(slice_id))
        apps = []
        for app_idx in self.etcd.get_prefix('{}/slice/{}/apps'.format(ETCD_PREFIX, slice_id)):
            app_id = json.loads(decode_utf8(app_idx[0])) if app_idx[0] else None
            if not app_id:
                continue
            action = self.get_slice_app_action(slice_id, app_id)
            if action and action.action == ActionEnum.DELETE:
                continue
            app = self.get_slice_app(slice_id, app_id)
            apps.append(app)
        return apps

    def get_all_slice_apps(self, slice_id):
        """
        Get all slice applications

        :param slice_id: Slice identifier
        :type slice_id: str
        :rtype: list
        """
        logger.debug("Get all slice {} applications".format(slice_id))
        return [self.get_slice_app(slice_id, json.loads(decode_utf8(app[0]))) for app in
                self.etcd.get_prefix('{}/slice/{}/apps'.format(ETCD_PREFIX, slice_id)) if app[0]]

    def save_slice_app_action(self, slice_id, app_id, action):
        """
        Add gateway slice action

        :param slice_id: Gateway identifier
        :param app_id: Application identifier
        :param action: Action to be taken on slice application
        :type slice_id: str
        :type app_id: str
        :type action: ActionModel
        """
        logger.debug("Save slice {} application {} action {}".format(slice_id, app_id, action.to_json()))
        self.etcd.put('{}/slice/{}/app/{}/action'.format(ETCD_PREFIX, slice_id, app_id), action.to_json())

    def get_slice_app_action(self, slice_id, app_id):
        """
        Get slice application action

        :param slice_id: Slice identifier
        :param app_id: Application identifier
        :type slice_id: str
        :type app_id: str
        :rtype: ActionModel
        """

        logger.debug("Get slice {} application {} action".format(slice_id, app_id))
        action = self.etcd.get('{}/slice/{}/app/{}/action'.format(ETCD_PREFIX, slice_id, app_id))[0]
        return ActionSchema().load(json.loads(decode_utf8(action)), unknown=INCLUDE) if action else None

    def del_slice_app_action(self, slice_id, app_id):
        """
        Delete slice application action

        :param slice_id: Slice identifier
        :param app_id: Application identifier
        :type slice_id: str
        :type app_id: str
        :returns: True if the action has been deleted
        :rtype: bool
        """
        logger.debug("delete slice {} application {} action".format(slice_id, app_id))
        return self.etcd.delete('{}/slice/{}/app/{}/action'.format(ETCD_PREFIX, slice_id, app_id))

    def save_slice_app_status(self, slice_id, app_id, status):
        """
        Add slice application status

        :param slice_id: Gateway identifier
        :param app_id: Application identifier
        :param status: Status of slice in gateway
        :type slice_id: str
        :type app_id: str
        :type status: AppStatusModel
        """
        logger.debug("Save slice {} application {} status {}".format(slice_id, app_id, status.to_json()))
        self.etcd.put('{}/slice/{}/app/{}/status'.format(ETCD_PREFIX, slice_id, app_id), status.to_json())

    def get_slice_app_status(self, slice_id, app_id):
        """
        Get slice application status

        :param slice_id: Gateway identifier
        :param app_id: Application identifier
        :type slice_id: str
        :type app_id: str
        :rtype: StatusModel
        """
        logger.debug("Get slice {} application {} status".format(slice_id, app_id))
        status = self.etcd.get('{}/slice/{}/app/{}/status'.format(ETCD_PREFIX, slice_id, app_id))[0]
        return AppStatusSchema().load(json.loads(decode_utf8(status)), unknown=INCLUDE) if status else None

    def delete_slice_app_status(self, slice_id, app_id):
        """
        Delete slice application status

        :param slice_id: Gateway identifier
        :param app_id: Application identifier
        :type slice_id: str
        :type app_id: str
        """
        logger.debug("Delete slice {} application {} status".format(slice_id, app_id))
        self.etcd.delete('{}/slice/{}/app/{}/status'.format(ETCD_PREFIX, slice_id, app_id))

    def add_gw_slice_tech_status(self, gw_id, slice_id, tech, status):
        """
        Add gateway slice technology status

        :param gw_id: Gateway identifier
        :param slice_id: Slice identifier
        :param tech: Technology [lora, nrf, wifi or zigbee]
        :param status: Status object
        :type gw_id: str
        :type slice_id: str
        :type tech: TechnologyEnum
        :type status: StatusModel
        """
        logger.debug("Add technology {} status {} on slice {} gateway {}".format(tech, status, slice_id, gw_id))
        self.etcd.put('{}/gw/{}/slice/{}/tech/{}/status'.format(ETCD_PREFIX, gw_id, slice_id, tech), status.to_json())

    def get_gw_slice_tech_status(self, gw_id, slice_id, tech):
        """
        Get gateway slice technology status

        :param gw_id: Gateway identifier
        :param slice_id: Slice identifier
        :param tech: Technology [lora, nrf, wifi or zigbee]
        :type gw_id: str
        :type slice_id: str
        :type tech: TechnologyEnum
        :rtype: StatusModel
        """
        logger.debug("Get gateway {} slice {} technology {} status".format(gw_id, slice_id, tech))
        status = self.etcd.get('{}/gw/{}/slice/{}/tech/{}/status'.format(ETCD_PREFIX, gw_id, slice_id, tech))[0]
        return StatusSchema().load(json.loads(decode_utf8(status)), unknown=INCLUDE) if status else None

    def delete_gw_slice_tech_status(self, gw_id, slice_id, tech):
        """
        Delete gateway slice technology status

        :param gw_id: gateway identifier
        :param slice_id: slice identifier
        :param tech: technology [lora, nrf, wifi or zigbee]
        :type gw_id: str
        :type slice_id: str
        :type tech: TechnologyEnum
        """
        logger.debug("Delete gateway {} slice {} technology {} status".format(gw_id, slice_id, tech))
        self.etcd.delete('{}/gw/{}/slice/{}/tech/{}/status'.format(ETCD_PREFIX, gw_id, slice_id, tech))

    def save_gw_slice_tech_lastconf(self, gw_id, slice_id, tech, data):
        """
        Last technology configuration

        :param gw_id: gateway identifier
        :param slice_id: slice identifier
        :param tech: technology [lora, nrf, wifi or zigbee]
        :param data: Technology object
        :type gw_id: str
        :type slice_id: str
        :type tech: TechnologyEnum
        :type data: TechModel
        """
        logger.debug("Save technology status {} on slice {}".format(tech, gw_id))
        self.etcd.put('{}/gw/{}/slice/{}/tech/{}/last'.format(ETCD_PREFIX, gw_id, slice_id, tech), data.to_json())

    def get_gw_slice_tech_lastconf(self, gw_id, slice_id, tech):
        """
        Get last technology configuration of slice in gateway

        :param gw_id: Gateway identifier
        :param slice_id: Slice identifier
        :param tech: technology [lora, nrf, wifi or zigbee]
        :type gw_id: str
        :type slice_id: str
        :type tech: TechnologyEnum
        :rtype: TechModel
        """
        if tech == TechnologyEnum.LORA:
            schema = LoraSchema
        elif tech == TechnologyEnum.NRF:
            schema = NRFSchema
        elif tech == TechnologyEnum.WIFI:
            schema = WifiSchema
        elif tech == TechnologyEnum.ZIGBEE:
            schema = ZigbeeSchema
        else:
            return Exception("Technology type '{}' not accepted. Use {}".format(tech, TechnologyEnum.ALL))

        logger.debug("Get technology {} on slice {}".format(tech, gw_id))
        slice_tech = self.etcd.get('{}/gw/{}/slice/{}/tech/{}/last'.format(ETCD_PREFIX, gw_id, slice_id, tech))[0]
        return schema().load(json.loads(decode_utf8(slice_tech)), unknown=INCLUDE) if slice_tech else None

    def get_gw_virtual_interfaces(self, gw_id, protocol, phy_iface):
        """
        Get virtual interface on gateway

        :param gw_id: Gateway identifier
        :param protocol: technology [lora, nrf, wifi or zigbee]
        :param phy_iface: physical interface name
        :type gw_id: str
        :type protocol: str
        :type phy_iface: str
        :rtype: list
        """
        logger.debug("Get all virtual interface of {} physical interface {}".format(protocol, phy_iface))
        interfaces = self.etcd.get_prefix(
            '{}/gw/{}/net/{}/iface/{}/vifaces'.format(ETCD_PREFIX, gw_id, protocol, phy_iface))
        return [VirtualInterfaceSchema().load(json.loads(decode_utf8(iface[0])), unknown=INCLUDE) for iface in
                interfaces]

    def save_gw_virtual_interface(self, id, protocol, phy_iface, data):
        """
        Save virtual interface on gateway

        :param id: Gateway identifier
        :param protocol: Technology [lora, nrf, wifi or zigbee]
        :param phy_iface: Physical interface name
        :param data: Virtual interface data
        :type id: str
        :type protocol: str
        :type phy_iface: str
        :type data: VirtualInterfaceModel
        """
        logger.debug("Save a {} virtal interface on iface {}: {}".format(protocol, phy_iface, data.to_json()))
        self.etcd.put('{}/gw/{}/net/{}/iface/{}/vifaces/{}'.format(ETCD_PREFIX, id, protocol, phy_iface, data.name),
                      data.to_json())

    def delete_gw_virtual_interface(self, gw_id, protocol, phy_iface, virt_iface):
        """
        Delete virtual interface on gateway

        :param gw_id: Gateway identifier
        :param protocol: Technology [lora, nrf, wifi or zigbee]
        :param phy_iface: Physical interface name
        :param virt_iface: Virtual interface name
        :type gw_id: str
        :type protocol: str
        :type phy_iface: str
        :type virt_iface: str
        """
        logger.debug("Delete {} virtal interface {} of slice {}".format(protocol, virt_iface, phy_iface))
        return self.etcd.delete('{}/gw/{}/net/{}/iface/{}/vifaces/{}'.format(ETCD_PREFIX, gw_id, protocol, phy_iface,
                                                                             virt_iface))

    def get_new_gateways(self, all=False):
        """
        Get all new_gateways
         :param all: Get all relationships, if True, otherwise, no
        :type all: bool
        :return: List of gateways
        :rtype: list
        """
        new_gws = [NewGatewaySchema().load(json.loads(decode_utf8(gw[0]))) for gw in
                   self.etcd.get_prefix('{}/new_gateways'.format(ETCD_PREFIX))]

        return new_gws

    def get_new_gateway(self, id):
        """
        Get new_gateway
         :param id: Gateway identifier
        :type id: str
        :rtype: GatewayModel
        :return: The gateway found, otherwise, None
        """
        data = self.etcd.get('{}/new_gateways/{}'.format(ETCD_PREFIX, id))[0]
        logger.debug('get_new_gateway: {}'.format(data))
        new_gateway = GatewaySchema().load(json.loads(decode_utf8(data)), unknown=INCLUDE) if data else None

        return new_gateway

    def save_new_gateway(self, new_gateway):
        logger.debug("Save new gateway {} as {}".format(new_gateway.id, new_gateway))
        self.etcd.put('{}/new_gateways/{}'.format(ETCD_PREFIX, new_gateway.id), new_gateway.to_json())
        return new_gateway

    def del_new_gateway(self, id):
        """
        Delete slice
         :param id: Slice identifier
        :type id: str
        :rtype: bool
        """
        logger.debug("Delete new_gateway {}".format(id))
        return self.etcd.delete_prefix('{}/new_gateways/{}'.format(ETCD_PREFIX, id))

    def get_token_gateway_install(self, all=False):
        token_gateway = [TokenGatewayInstallSchema().load(json.loads(decode_utf8(token_gw[0]))) for token_gw in
                         self.etcd.get_prefix('{}/softway_token_key'.format(ETCD_PREFIX))]

        return token_gateway

    def save_token_gateway_install(self, token_gateway):
        logger.debug("Save new token gateway {} as {}".format(token_gateway.key, token_gateway))
        self.etcd.put('{}/softway_token_key/'.format(ETCD_PREFIX), token_gateway.to_json())
        return token_gateway

    def generate_softway_encrypt_key(self):
        key = self.etcd.get('{}/softway_encrypt_key/'.format(ETCD_PREFIX))[0]
        if key is None:
            key = Fernet.generate_key()
            logger.debug("Save new softway encrypt key {} ".format(key))
            self.etcd.put('{}/softway_encrypt_key/'.format(ETCD_PREFIX), key)
        return key

    def get_softway_encrytp_key(self, all=False):
        key = self.etcd.get('{}/softway_encrypt_key/'.format(ETCD_PREFIX))[0]
        return key

    def save_user(self, user):
        data = self.etcd.get('{}/users/{}'.format(ETCD_PREFIX, user.username))[0]
        if data is not None:
            raise Exception("User {} already exists".format(user.username))

        password = user.password

        #Encrypt user password
        key = self.get_softway_encrytp_key();
        f = Fernet(key)
        password = f.encrypt(password)

        user.password = password

        logger.debug("Save user {} as {}".format(user.username, user))
        self.etcd.put('{}/users/{}'.format(ETCD_PREFIX, user.username), user.to_json())
        return user

    def del_user(self, id):
        """
        Delete user

        :param id: User identifier
        :type id: str
        :rtype: bool
        """
        logger.debug("Delete user {}".format(id))
        return self.etcd.delete_prefix('{}/users/{}'.format(ETCD_PREFIX, id))

    def get_users(self, all=False):
        """
        Get all users

        :param all: Get all relationships, if True, otherwise, no
        :rtype: list
        :return: List of all slices found
        """
        users = [UserSchema().load(json.loads(decode_utf8(s[0])), unknown=INCLUDE) for s in
                  self.etcd.get_prefix('{}/users'.format(ETCD_PREFIX))]

        if all:
            key = self.get_softway_encrytp_key();
            f = Fernet(key)
            for user in users:
                password = user.password
                password = f.encrypt(password)
                user.password = password
        return users

    def get_user(self, username, password):
        data = self.etcd.get('{}/users/{}'.format(ETCD_PREFIX, username))[0]
        logger.debug('get user: {}'.format(data))
        user = UserSchema().load(json.loads(decode_utf8(data)), unknown=INCLUDE) if data else None

        key = self.get_softway_encrytp_key();
        f = Fernet(key)

        if (password == f.decrypt(user.password)):
            return user

    def save_revoked_token(self, revoked_token):
        self.etcd.put('{}/revoked_tokens/{}'.format(ETCD_PREFIX, revoked_token), revoked_token.to_json())

    def is_jti_blacklisted(self, jti):
        data = self.etcd.get('{}/revoked_tokens/{}'.format(ETCD_PREFIX, jti))[0]
        blacklisted = RevokedTokenSchema().load(json.loads(decode_utf8(data)), unknown=INCLUDE) if data else None
        if blacklisted:
            return True
        return False
