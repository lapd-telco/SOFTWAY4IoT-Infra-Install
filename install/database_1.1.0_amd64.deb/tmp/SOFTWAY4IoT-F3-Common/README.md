# SOFTWAY4IoT-F3-Common
Code shared by components of SOFTWAY4IoT.

## How to use:

### Add in requeriments.txt follow code:
```python
-e git+file:/path/to/src/SOFTWAY4IoT-F3-Common#egg=sw4iotdatabase
```
### Import library in code:
```python
import sw4iotdatabase
```
