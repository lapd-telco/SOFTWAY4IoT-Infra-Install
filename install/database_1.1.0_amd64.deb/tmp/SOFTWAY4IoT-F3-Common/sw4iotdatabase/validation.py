import requests
import validators
from marshmallow import ValidationError

from sw4iotdatabase.models import SecurityTypeEnum, TechnologyEnum


def url(url):
    """
    Return whether or not given value is a valid URL.

    :param url: URL string to validate
    :type url: str
    """
    if not validators.url(url) or requests.get(url).status_code != 200:
        raise ValidationError("Invalid url: {}".format(url))


def mac_address(mac):
    """
    Return whether or not given value is a valid MAC address.

    :param mac: Mac address string to validate
    :type mac: str
    """
    if not validators.mac_address(mac):
        raise ValidationError("Invalid mac address")


def technology(tech):
    """
    Return whether or not given value is a valid Technology.

    :param tech: Technology type to validate
    :type tech: str
    """
    if tech not in TechnologyEnum.ALL:
        raise ValidationError("Invalid technology")


def security(sec):
    """
    Return whether or not given value is a valid security type.

    :param sec: Security type to validate
    :type sec: str
    """
    if sec not in SecurityTypeEnum.ALL:
        raise ValidationError("Invalid security")


def spec_kinds(kind):
    """
    Return whether or not given value is a valid kind in specification. Required (Application or Service)

    :param kind: Specification kind type to validate
    :type kind: str
    """
    KINDS=['Application', 'Service']
    if kind not in KINDS:
        raise ValidationError("Kind '{}' invalid. Accept only {}".format(kind, KINDS))
