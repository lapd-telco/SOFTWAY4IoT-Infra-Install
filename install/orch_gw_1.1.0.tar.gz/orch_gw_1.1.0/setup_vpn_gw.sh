#!/bin/bash

ip_gm=$1
private_ip_gw=$2
public_ip_gw=$3
ip_gw_subnet_data=$4
ip_gw_subnet_control=$5
ip_bridge_data=$6
ip_bridge_control=$7

cat >> /etc/sysctl.conf << EOF
net.ipv4.ip_forward = 1
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
EOF

sysctl -p /etc/sysctl.conf

cat >> ipsec.conf << EOF
# basic configuration
config setup
        charondebug="all"
        uniqueids=yes
        strictcrlpolicy=no
EOF

cp ipsec.conf /etc/ipsec.conf
rm ipsec.conf

key=`cat /opt/softway4iot/vpn_keys/key`

cat >> /etc/ipsec.secrets << EOF
$public_ip_gw $ip_gm : PSK $key
EOF

cat >> /etc/ipsec.conf << EOF

# connection to Gateway

conn gm-to-gw
	authby=secret
	left=$private_ip_gw
	leftid=$public_ip_gw
	right=$ip_gm
	ike=aes256-sha2_256-modp1024!
	esp=aes256-sha2_256!
	leftsubnet=$ip_gw_subnet_data
	rightsubnet=10.249.1.0/24
	keyingtries=0
	ikelifetime=1h
	lifetime=8h
	dpddelay=30
	dpdtimeout=120
	dpdaction=restart
	auto=start

conn gm1-to-gw
	authby=secret
	left=$private_ip_gw
	leftid=$public_ip_gw
	right=$ip_gm
	ike=aes256-sha2_256-modp1024!
	esp=aes256-sha2_256!
	leftsubnet=$ip_gw_subnet_control
	rightsubnet=10.250.1.0/24
	keyingtries=0
	ikelifetime=1h
	lifetime=8h
	dpddelay=30
	dpdtimeout=120
	dpdaction=restart
	auto=start

EOF

iptables -t nat -A POSTROUTING -s 10.249.1.1/24 -d $ip_gw_subnet_data -j MASQUERADE
iptables -t nat -A POSTROUTING -s 10.250.1.1/24 -d $ip_gw_subnet_control -j MASQUERADE
iptables -t nat -A POSTROUTING -s 192.168.1.0/16 -d 10.249.1.1/24 -j SNAT --to-source $ip_bridge_data
iptables -t nat -A POSTROUTING -s 192.168.1.0/16 -d 10.250.1.1/24 -j SNAT --to-source $ip_bridge_control

sleep 10

ipsec restart

