# -*- coding: utf-8 -*-
import logging
from apscheduler.schedulers.blocking import BlockingScheduler

from sw4iotdatabase.models import InterfaceModel
# from drivers.zigbee import zigbee_driver
from driver.monitor import driver_monitor
from driver.lora import lora_driver

# logging
logging.basicConfig(filename='softway-lora-driver.log', filemode='w', level=logging.ERROR)
logging.getLogger('apscheduler').setLevel(logging.WARNING)
logging.getLogger('drivers').setLevel(logging.DEBUG)
#
FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s' 
logging.basicConfig(format=FORMAT)
logger = logging.getLogger('sw4iot-drivers')
logger.setLevel(logging.INFO)

scheduler = BlockingScheduler(timezone="UTC")

scheduler.add_job(driver_monitor, 'interval', seconds=5, id='lora_{}'.format(driver_monitor.__name__),
                  replace_existing=True, args=[lora_driver, InterfaceModel.type.LORA])

# scheduler.add_job(driver_monitor, 'interval', seconds=5, id='zigbee_{}'.format(driver_monitor.__name__),
#                   replace_existing=True, args=[zigbee_driver, InterfaceTypeEnum.ZIGBEE])

try:
    logger.info("Starting Drivers scheduler")
    scheduler.start()
except SystemExit:
    logger.error("Exit Drivers scheduler")
    scheduler.remove_all_jobs()  # TODO remove this
    logger.info("All jobs have been removed")
