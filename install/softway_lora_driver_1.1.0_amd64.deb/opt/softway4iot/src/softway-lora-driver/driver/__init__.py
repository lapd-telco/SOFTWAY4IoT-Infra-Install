from typing import Dict

daemon_iface_driver = {}  # type: Dict[str, bool]
