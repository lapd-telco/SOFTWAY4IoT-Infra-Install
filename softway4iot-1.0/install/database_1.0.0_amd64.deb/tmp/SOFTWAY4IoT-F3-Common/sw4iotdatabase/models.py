import hashlib
import json
from datetime import datetime


def data_converter(o):
    if isinstance(o, datetime):
        return o.__str__()
    else:
        return o.__dict__


class JsonSerializable(object):

    def to_json(self):
        return json.dumps(self.to_dict(), default=data_converter)

    def __repr__(self):
        return self.to_json()

    def to_dict(self):
        return self.__dict__


class Model(JsonSerializable):
    def update_obj(self, data: dict):
        """

        :type data: dict
        """
        for key in data.keys():
            setattr(self, key, data[key]) if hasattr(self, key) else None


class ActionEnum:
    INSTALL = 'install'
    DELETE = 'delete'
    REBUILD = 'rebuild'
    NONE = 'none'
    RELEASE = 'release'


class StatusEnum:
    INSTALLING = 'installing'
    INSTALLED = 'installed'
    DELETING = 'deleting'
    DELETED = 'deleted'
    REBUILDING = 'rebuilding'
    ERROR = 'error'
    OK = 'ok'
    NOT_OK = 'not_ok'


class InterfaceTypeEnum:
    ZIGBEE = 'zigbee'
    LORA = 'lora'
    WIFI = 'wifi'
    NRF = 'nrf'
    ALL = [ZIGBEE, LORA, WIFI, NRF]


class SecurityTypeEnum:
    NAT = 'nat'
    ALL = [NAT]


class TechnologyEnum:
    ZIGBEE = 'zigbee'
    LORA = 'lora'
    WIFI = 'wifi'
    NRF = 'nrf'
    ALL = [ZIGBEE, LORA, WIFI, NRF]


class SliceModel(Model):
    def __init__(self, id, name, description, net=None, vlan=None, enabled=False, action=None, status=None,
                 released=None):
        self.id = id
        self.name = name
        self.description = description
        self.net = net
        self.vlan = vlan
        self.enabled = enabled
        self.action = action
        self.status = status
        self.released = released

    @staticmethod
    def from_dict(data):
        return SliceModel(**data)


class SliceNetModel(Model):
    def __init__(self, tenant, network, group, nat_policy, subnet, gateway, netmask, dns):
        self.tenant = tenant
        self.network = network
        self.group = group
        self.nat_policy = nat_policy
        self.subnet = subnet
        self.gateway = gateway
        self.netmask = netmask
        self.dns = dns

    @staticmethod
    def from_dict(data):
        return SliceNetModel(**data)


class VlanModel(Model):
    def __init__(self, vlan, slice):
        self.vlan = vlan
        self.slice = slice

    @staticmethod
    def from_dict(data):
        return VlanModel(**data)


class GatewayModel(Model):
    def __init__(self, id, name, location=None, description=None, enabled=None, info=None):
        """

        :type id: str
        :type name: str
        :type location: LocationModel
        :type description: str
        :type enabled: bool
        :type info: GatewayInfoModel
        """
        self.id = id
        self.name = name
        self.location = location
        self.description = description
        self.enabled = enabled
        self.info = info

    @staticmethod
    def from_dict(data):
        return GatewayModel(**data)


class GatewayInfoModel(Model):
    def __init__(self, machine=None, node_name=None, release=None, sys_name=None, version=None, ip=None,
                 architecture=None):
        self.machine = machine
        self.node_name = node_name
        self.release = release
        self.sys_name = sys_name
        self.version = version
        self.ip = ip
        self.architecture = architecture

    @staticmethod
    def from_dict(data):
        return GatewayModel(**data)


class LocationModel(Model):
    def __init__(self, latitude, longitude):
        self.latitude = latitude
        self.longitude = longitude

    @staticmethod
    def from_dict(data):
        return LocationModel(**data)


class PatchModel(Model):

    def __init__(self, patch0, patch1):
        """
        Patch interfaces
        """
        self.patch0 = patch0
        self.patch1 = patch1

    @staticmethod
    def from_dict(data):
        return PatchModel(**data)


class DefaultNetConfigModel(Model):

    def __init__(self, vxlan, seg, patch):
        """
        Default net configuration

        :param vxlan: vxlan bridge
        :param seg; segmentation bridge
        :param patch: patch ports to connect vxlan and seg bridges
        :type vxlan: str
        :type seg: str
        :type patch: PatchModel
        """
        self.vxlan = vxlan
        self.seg = seg
        self.patch = patch

    @staticmethod
    def from_dict(data):
        return DefaultNetConfigModel(**data)


class VethPeerLinkModel(Model):
    def __init__(self, veth0, veth1):
        self.veth0 = veth0
        self.veth1 = veth1

    @staticmethod
    def from_dict(data):
        return VethPeerLinkModel(**data)


class SliceConnectionModel(Model):
    def __init__(self, br_slice, veth_slice, br_wifi, veth_wifi):
        """
        Slice connection

        :type br_slice: str
        :type veth_slice: VethPeerLinkModel
        :type br_wifi: str
        :type veth_wifi: VethPeerLinkModel
        """
        self.br_slice = br_slice
        self.veth_slice = veth_slice
        self.br_wifi = br_wifi
        self.veth_wifi = veth_wifi

    @staticmethod
    def from_dict(data):
        return SliceConnectionModel(**data)


class NetDeviceModel(Model):
    def __init__(self, peer=None, ip_address=None, ofport=None, host=None, group_id=None, vport_mac=None):
        """
        Network device

        :type peer: VethPeerLinkModel
        """
        self.peer = peer
        self.ip_address = ip_address
        self.ofport = ofport
        self.host = host  # TODO: remove this host
        self.group_id = group_id
        self.vport_mac = vport_mac

    @staticmethod
    def from_dict(data):
        return NetDeviceModel(**data)


class DeviceModel(Model):
    def __init__(self, id, description, technology, enabled, endpoint_id=None, mac=None, host=None, net=None,
                 action=None):
        self.id = id
        self.mac = mac
        self.description = description
        self.technology = technology
        self.enabled = enabled
        self.endpoint_id = endpoint_id
        self.host = host
        self.net = net
        self.action = action

    @staticmethod
    def from_dict(data):
        return DeviceModel(**data)


class SimpleDeviceModel(Model):
    def __init__(self, id, slice):
        self.id = id
        self.slice = slice

    @staticmethod
    def from_dict(data):
        return SimpleDeviceModel(**data)


class TechStatusModel(Model):
    def __init__(self, status=None, update_at=None):
        self.status = status
        self.updated_at = update_at


class TechActionModel(Model):
    def __init__(self, action=None):
        self.action = action

    @staticmethod
    def from_dict(data):
        return TechActionModel(**data)


class ActionModel(Model):
    def __init__(self, action=None, updated_at=None):
        self.action = action
        self.updated_at = updated_at

    @staticmethod
    def from_dict(data):
        return ActionModel(**data)


class StatusModel(Model):
    def __init__(self, status=None, msg=None, updated_at=None):
        self.status = status
        self.msg = msg
        self.updated_at = updated_at

    @staticmethod
    def from_dict(data):
        return StatusModel(**data)


class UpdatedAtModel(Model):
    def __init__(self, updated_at=None):
        self.updated_at = updated_at

    @staticmethod
    def from_dict(data):
        return UpdatedAtModel(**data)


class TechModel(Model):
    def __init__(self, updated_at=None, hash=None, statuses=None):
        self.updated_at = updated_at
        self.hash = hash
        self.statuses = statuses

    def make_hash(self, data):
        self.hash = hashlib.sha224("{}".format(data).encode('utf-8')).hexdigest()


class LoraModel(TechModel):
    def __init__(self, enabled, app_id, updated_at=None, hash=None, statuses=None):
        super().__init__(updated_at, hash, statuses)
        self.enabled = enabled
        self.app_id = app_id

    def make_hash(self, data=None):
        super(LoraModel, self).make_hash("{}".format(self.app_id))


class NRFModel(TechModel):
    def __init__(self, enabled, app_id, updated_at=None, hash=None, statuses=None):
        super().__init__(updated_at, hash, statuses)
        self.enabled = enabled
        self.app_id = app_id

    def make_hash(self, data=None):
        super(NRFModel, self).make_hash("{}".format(self.app_id))


class ZigbeeModel(TechModel):
    def __init__(self, enabled, app_id, updated_at=None, hash=None, statuses=None):
        super().__init__(updated_at, hash, statuses)
        self.enabled = enabled
        self.app_id = app_id

    def make_hash(self, data=None):
        super(ZigbeeModel, self).make_hash("{}".format(self.app_id))


class WifiModel(TechModel):
    def __init__(self, enabled, password, ssid=None, channel=1, security='1+2', gateways=None, updated_at=None,
                 hash=None, statuses=None):
        super().__init__(updated_at, hash, statuses)
        self.enabled = enabled
        self.ssid = ssid
        self.channel = channel
        self.security = security
        self.password = password
        self.gateways = gateways

    def make_hash(self, data=None):
        super(WifiModel, self).make_hash("{}+{}".format(self.ssid, self.password))


class SecurityModel(Model):
    def __init__(self, enabled, updated_at=None):
        self.enabled = enabled
        self.updated_at = updated_at


class InterfaceModel(Model):
    type = InterfaceTypeEnum

    def __init__(self, type, name, device, manufacturer, product=None, vid=None, pid=None, max_vnets=-1, hwid=None,
                 options=None, updated_at=None):
        self.type = type
        self.name = name
        self.device = device
        self.manufacturer = manufacturer
        self.product = product
        self.vid = vid
        self.pid = pid
        self.max_vnets = max_vnets
        self.hwid = hwid
        self.options = options
        self.updated_at = updated_at


class VirtualInterfaceModel(Model):

    def __init__(self, name, slice, updated_at=None):
        self.name = name
        self.slice = slice
        self.updated_at = updated_at


class AppModel(Model):

    def __init__(self, url, id=None, name=None, data=None, status=None,
                 labels=None, updated_at=None):
        self.url = url
        self.id = id
        self.name = name
        self.data = data
        self.updated_at = updated_at
        self.status = status
        self.labels = labels


class AppStatusModel(Model):

    def __init__(self, host_ip=None, message=None, phase=None, pod_ip=None, qos_class=None, reason=None,
                 start_time=None, mac=None, homing_host=None, container_statuses=None):
        self.host_ip = host_ip
        self.message = message
        self.phase = phase
        self.pod_ip = pod_ip
        self.qos_class = qos_class
        self.reason = reason
        self.start_time = start_time
        self.mac = mac
        self.homing_host = homing_host
        self.container_statuses = container_statuses


class ContainerStateTerminatedModel(Model):

    def __init__(self, container_id=None, finished_at=None, message=None, signal=None, reason=None, started_at=None,
                 exit_code=None):
        self.container_id = container_id
        self.finished_at = finished_at
        self.message = message
        self.signal = signal
        self.reason = reason,
        self.started_at = started_at
        self.exit_code = exit_code


class ContainerStateRunningModel(Model):

    def __init__(self, started_at=None):
        self.started_at = started_at


class ContainerStateWaitingModel(Model):

    def __init__(self, message=None, reason=None):
        self.message = message
        self.reason = reason


class ContainerStateModel(Model):

    def __init__(self, running=None, terminated=None, waiting=None):
        self.running = running
        self.terminated = terminated
        self.waiting = waiting


class ContainerStatusModel(Model):

    def __init__(self, image=None, name=None, ready=None, restart_count=None, state=None):
        self.image = image
        self.name = name
        self.ready = ready
        self.restart_count = restart_count
        self.state = state


class PodKubernetes(Model):

    def __init__(self):
        pass

    def make_from_app(self, app):
        pass


class Sw4IotSpec(Model):

    def __init__(self, app_name, app_spec, contiv):
        if app_spec['kind'] == 'Application':
            self.data = self.make_application_spec(app_name, app_spec['containers'], contiv)

    def make_application_spec(self, app_name, containers, contiv):
        return {
            'apiVersion': 'v1',
            'kind': 'Pod',
            'metadata': {
                'labels': {
                    'k8s-app': app_name,
                    'io.contiv.tenant': contiv['tenant'],
                    'io.contiv.network': contiv['network'],
                    'io.contiv.net-group': contiv['net-group'],
                },
                'name': app_name
            },
            'spec': {
                'containers': containers,
                'dnsPolicy': 'None',
                'dnsConfig': {
                    'nameservers': ['8.8.8.8'],
                    'searches': ['custom.dns.local']
                }
            }
        }

class NewGatewayModel(Model):
    def __init__(self, id, ip_address):
        self.id = id
        self.ip_address = ip_address

    @staticmethod
    def from_dict(data):
        return NewGatewayModel(**data)

class TokenGatewayInstallModel(Model):
    def __init__(self, key, creation_date):
        self.key = key
        self.creation_date = creation_date

    @staticmethod
    def from_dict(data):
        return TokenGatewayInstallModel(**data)