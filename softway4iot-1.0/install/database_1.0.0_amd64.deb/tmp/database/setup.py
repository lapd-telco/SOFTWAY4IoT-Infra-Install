import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="example-pkg-your-username",
    version="1.0.0",
    author="SOFTWAY4IoT",
    author_email="kleber@inf.ufg.br",
    description="Database shared by SOFTWAY4IoT modules",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/LABORA-INF-UFG/SOFTWAY4IoT-F3-Common",
    install_requires=['etcd3>=0.8.1', 'marshmallow==3.0.0rc3', 'python-dateutil>=2.7.5', 'pyyaml>=3.13',
                      'requests>=2.21', 'validators>=0.12'],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
