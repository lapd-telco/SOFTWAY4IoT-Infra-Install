from sw4iotdatabase.database import Sw4IotDatabase
from sw4iotdatabase.models import GatewayModel, GatewayInfoModel
from sw4iotdatabase.utils import getinfo, getip

import requests
import time
import sys
import os


from urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)


def __headers(token=False):
    headers = {
        'Content-Type': 'application/json',
    }
    if token:
        headers['X-Auth-Token'] = token
    return headers


def get_ca_file_docker(url, token, path_save_file):
    path = url + "file/ca/" + token

    path_file = path_save_file + "ca.pem"

    r = requests.get(path, json=params, headers=__headers(), verify=False)

    with open(path_file, "wb") as f:
        f.write(r.content)


def get_server_cert_file_docker(url, token, path_save_file):
    path = url + "file/server_cert/" + token
    r = requests.get(path, json=params, headers=__headers(), verify=False)

    path_file = path_save_file + "server-cert.pem"

    with open(path_file, "wb") as f:
        f.write(r.content)


def get_server_key_file(url, token, path_save_file):
    path = url + "file/server_key/" + token
    r = requests.get(path, json=params, headers=__headers(), verify=False)

    path_file = path_save_file + "server-key.pem"

    with open(path_file, "wb") as f:
        f.write(r.content)


def get_vpn_key_file(url, token):
    path = url + "file/vpn_key/" + token
    r = requests.get(path, json=params, headers=__headers(), verify=False)

    path_file = "/opt/softway4iot/vpn_keys/key"

    with open(path_file, "wb") as f:
        f.write(r.content)


def register_new_gateway(url, token, params):
    path = url + "new_gateways/" + token

    r = requests.post(path, json=params, headers=__headers(), verify=False)
    print(r.content)
    print("\n")


def setup_vpn(id, ip_gateway_manager, private_ip_gateway, public_ip_gateway):
    ip_gw_subnet_data = "10.249." + str(id) + ".1/24"
    ip_gw_subnet_control = "10.250." + str(id) + ".1/24"
    ip_bridge_data = "10.249." + str(id) + ".1"
    ip_bridge_control = "10.250." + str(id) + ".1"

    command = "sudo ./setup_vpn_gw.sh " + str(ip_gateway_manager) + " " + str(private_ip_gateway) + " " + \
              str(public_ip_gateway) + " " + str(ip_gw_subnet_data) + " " + str(ip_gw_subnet_control) + " " + \
              str(ip_bridge_data) + " " + str(ip_bridge_control)

    os.system(command)


if __name__ == "__main__":
    id = sys.argv[1]
    ip_gateway_manager = sys.argv[2]
    ip_etcd = sys.argv[3]
    private_ip_gateway = sys.argv[4]
    public_ip_gateway = sys.argv[5]
    token = sys.argv[6]

    path_save_file = "/opt/softway4iot/docker_certs/"

    url = "https://" + str(ip_gateway_manager) + ":5000/api/v1/"
    params = {'id': str(id), 'ip_address': str(public_ip_gateway)}

    register_new_gateway(url, token, params)

    # Get Docker certificates and keys
    get_ca_file_docker(url, token, path_save_file)
    get_server_cert_file_docker(url, token, path_save_file)
    get_server_key_file(url, token, path_save_file)

    # Get VPN key
    get_vpn_key_file(url, token)

    setup_vpn(id, ip_gateway_manager, private_ip_gateway, public_ip_gateway)

    time.sleep(20)

    db = Sw4IotDatabase('10.250.1.4')
    gw = GatewayModel(id, id, enabled=True)
    db.save_gateway(gw)
    gw_info = GatewayInfoModel(**getinfo())
    gw_info.ip = getip()
    db.save_gw_info(id, gw_info)

    command = "sudo iptables-save > /opt/softway4iot/conf/iptables-save"
    os.system(command)
