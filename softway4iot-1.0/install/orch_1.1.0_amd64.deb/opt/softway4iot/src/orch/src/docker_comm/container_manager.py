class ContainerManager:

    def __init__(self):
        pass

    def run_container(self, name):
        """
        Receive information of container and run
        :param name:
        :return:
        """
        pass

    def stop_container(self, id):
        """

        :param id: id of container to stop
        :return:
        """
        pass
