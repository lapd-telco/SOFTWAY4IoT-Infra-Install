import logging
import time
import ast
import docker
import json
import os
import yaml
import uuid
from datetime import datetime
from src.docker_comm.clients_manager import ClientsManager
from sw4iotdatabase import database
from sw4iotdatabase.utils import get_yaml_content
from sw4iotdatabase.schemas import ActionSchema
from sw4iotdatabase.models import ActionModel, AppStatusModel, ActionEnum, TokenGatewayInstallModel

db = database.Sw4IotDatabase()

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def yaml_validate(yaml_file):

    services = yaml_file["services"]

    for item in services:
        container = services[item]

        if 'gateway' in container:
            if 'image' in container:
                continue

        else:
            return False

    return True


def get_docker_client(slice, host):
    if host == 'host':
        return docker.from_env()
    else:
        certs_path = '/opt/softway4iot/docker_certs'
        tls_config = docker.tls.TLSConfig(
            client_cert=(certs_path + '/client-softway4iot-gatweway-cert.pem',
                         certs_path + '/client-softway4iot-gatweway-key.pem'))
        for gateway in db.get_slice_gws(slice.id):
            if str(gateway.id) == str(host):
                gateway_ip = "10.250." + str(host) + ".1:2375"
        dockerClient = docker.DockerClient(base_url='tcp://' + str(gateway_ip), tls=tls_config)
    return dockerClient


def get_container_mac(container_id):
    cont = 0
    mac = "c2:"
    for char in container_id[0:10]:
        if cont == 0:
            mac = mac + str(char)
            cont += 1
        else:
            mac = mac + str(char)
            mac = mac + ':'
            cont = 0
    return mac[0:17]


def apps_create():
    slices = db.get_slices()
    for slice in slices:
        slice.enabled = db.get_slice_enabled(slice.id)
        if slice.enabled:
            apps = db.get_slice_apps(slice.id)
            for app in apps:
                action_app = db.get_slice_app_action(slice.id, app.id)
                if action_app and action_app.action != ActionEnum.INSTALL:
                    continue
                app_status = db.get_slice_app_status(slice.id, app.id)
                if app_status is not None and app_status.phase == 'Rerun':
                    logger.info("Rerun app {}".format(app))
                    app_status = None
                if app_status is not None:
                    continue
                json_file = json.loads(str(app))
                logger.info("Create App {}".format(str(app)))
                yaml_file = get_yaml_content(json_file["url"])
                id = 0
                if yaml_validate(yaml_file):
                    hosts_dict = {}
                    container_dict = {}
                    mac_dict = {}
                    services = yaml_file["services"]
                    for item in services:
                        container = services[item]
                        logger.info("Run container {}".format(str(container)))
                        gateway = container["gateway"]
                        port_list = []
                        if 'ports' in container:
                            for port in container["ports"]:
                                port_list.append(str(port))
                        hosts_dict[id] = gateway
                        docker_requisition = ClientsManager(get_docker_client(slice, gateway))
                        container_id = docker_requisition.run_container(container)
                        dict_container = {}
                        mac_dict[id] = get_container_mac(container_id)
                        dict_container['id'] = container_id[0:10]
                        dict_container['ports'] = port_list
                        container_dict[id] = str(dict_container)
                        id = id + 1
                    app_status = AppStatusModel(str(hosts_dict), str(container_dict), 'Waiting', None, None, None,
                                                None, str(mac_dict), None, None)
                    db.save_slice_app_status(slice.id, app.id, app_status)
                else:
                    logger.info("Yaml error {}".format(str(yaml_file)))
                    app_status = AppStatusModel(None, None, 'Error', None, None, None, None, None, None,
                                                None)
                    db.save_slice_app_status(slice.id, app.id, app_status)


def rerun_app(slice_id, app_id):
    app_status = AppStatusModel(None, None, 'Rerun', None, None, None, None, None, None, None)
    db.save_slice_app_status(slice_id, app_id, app_status)
    db.save_slice_app_action(slice_id, app_id, ActionSchema().load(ActionModel(action=ActionEnum.INSTALL).to_dict()))


def apps_status():
    sw4iot_infra_status()
    slices = db.get_slices()
    for slice in slices:
        slice.enabled = db.get_slice_enabled(slice.id)
        apps = db.get_slice_apps(slice.id)
        if slice.enabled:
            for app in apps:
                status = db.get_slice_app_status(slice.id, app.id)
                action_app = db.get_slice_app_action(slice.id, app.id)
                if not action_app or action_app.action != ActionEnum.INSTALL:
                    continue
                if status:
                    if status.phase == 'Running':
                        message = status.message
                        message = ast.literal_eval(message)
                        host_list = status.host_ip
                        host_list = ast.literal_eval(host_list)
                        for item in message:
                            container = message[item]
                            container = ast.literal_eval(container)
                            gateway = host_list[item]
                            container_id = container['id']
                            docker_requisition = ClientsManager(get_docker_client(slice, gateway))
                            if not action_app or action_app.action == ActionEnum.DELETE:
                                continue
                            if not docker_requisition.is_container_running(container_id):
                                logger.info("Container {} is not Running".format(container_id))
                                if docker_requisition.start_container(id=container_id):
                                    app_status = status
                                    app_status.phase = 'Waiting'
                                    db.save_slice_app_status(slice.id, app.id, app_status)
                                    logger.info("Container {} is Running".format(container_id))
                                else:
                                    logger.info("Container {} not found".format(container_id))
                                    rerun_app(slice.id, app.id)


def apps_delete():
    slices = db.get_slices()
    for slice in slices:
        apps = db.get_all_slice_apps(slice.id)
        for app in apps:
            action_app = db.get_slice_app_action(slice.id, app.id)
            if not action_app or action_app.action != ActionEnum.DELETE:
                continue
            status = db.get_slice_app_status(slice.id, app.id)
            if status and status.phase == 'Terminated':
                continue
            logger.info("Delete App {}".format(str(app)))
            message = str(status.message)
            message = ast.literal_eval(message)
            container_list = {}
            k = 0
            for item in message:
                dict_id = message[item]
                dict_id = ast.literal_eval(dict_id)
                container_list[k] = dict_id["id"]
                k += 1
            hosts_ip = str(status.host_ip)
            hosts_ip = ast.literal_eval(str(hosts_ip))
            for item in container_list:
                logger.info("Stop container {}".format(str(item)))
                container = container_list[item]
                gateway = hosts_ip[item]
                dockerClient = get_docker_client(slice, gateway)
                docker_requisition = ClientsManager(dockerClient)
                docker_requisition.stop_container(container)
                docker_requisition.remove_container(container)
            db.save_slice_app_action(slice.id, app.id, ActionSchema().load(ActionModel(action='terminated').to_dict()))


def sw4iot_infra_status():
    dockerClient = docker.from_env()
    docker_requisition = ClientsManager(dockerClient)
    if not docker_requisition.is_container_running(name='etcd'):
        if docker_requisition.start_container(name='etcd'):
            os.system('sudo ovs-docker del-port br-control eth02 etcd')
            os.system('sudo ovs-docker add-port br-control eth02 etcd --ipaddress=10.250.1.4/24 '
                      '--gateway=10.250.1.1 --mtu=1400')
            command = 'etcd --name sw4iot --data-dir sw4iot --auto-tls --peer-auto-tls '\
                      '--initial-advertise-peer-urls=http://10.250.1.4:2380 '\
                      '--listen-peer-urls=http://10.250.1.4:2380 --listen-client-urls http://10.250.1.4:2379 '\
                      '--advertise-client-urls http://10.250.1.4:2379'

            if docker_requisition.exec_command(name='etcd', command=command):
                time.sleep(10)

            logger.info("ETCD is running")
    if not docker_requisition.is_container_running(name='apiserver'):
        if docker_requisition.start_container(name='apiserver'):
            os.system('sudo ovs-docker del-port br-control eth02 apiserver')
            os.system('sudo ovs-docker add-port br-control eth02 apiserver '
                      '--ipaddress=10.250.1.2/24 --gateway=10.250.1.1 --mtu=1400')
            logger.info('API-SERVER is running')

    if not docker_requisition.is_container_running(name='websm'):
        if docker_requisition.start_container(name='websm'):
            os.system('sudo ovs-docker del-port br-control eth02 websm')
            os.system('sudo ovs-docker add-port br-control eth02 websm '
                      '--ipaddress=10.250.1.3/24 --gateway=10.250.1.1 --mtu=1400')
            logger.info('WEBSM is running')

    if not docker_requisition.is_container_running(name='fiwaremanager'):
        if docker_requisition.start_container(name='fiwaremanager'):
            os.system('sudo ovs-docker del-port br-control eth02 fiwaremanager')
            os.system('sudo ovs-docker add-port br-control eth02 fiwaremanager '
                      '--ipaddress=10.250.1.5/24 --gateway=10.250.1.1 --mtu=1400')
            logger.info('FIWARE-MANAGER is running')


def netslice_delete_devices_without_ip():
    slices = db.get_slices()
    for slice in slices:
        devices_to_delete = [dev for dev in db.get_slice_devices(slice.id, all=True) if
                             not dev.host and dev.action and dev.action.action == ActionEnum.DELETE]
        if not devices_to_delete:
            continue
        logger.info("Slice {} devices to delete {}".format(slice.id, [dev.id for dev in devices_to_delete]))
        for device in devices_to_delete:
            db.delete_slice_device(slice.id, device.id, all=True)
            db.delete_device(device.id, all=True)
            logger.info("Device {} of slice {} deleted".format(device.id, slice.id))


def token_create():
    logger.info("Create Token")
    now = datetime.now()
    token = TokenGatewayInstallModel(str(uuid.uuid1()), str(now))
    db.save_token_gateway_install(token)


def interface_wifi_create():
    slices = db.get_slices()
    for slice in slices:
        tech = db.get_slice_tech(slice.id, 'wifi')
        if tech:
            if tech.enabled:
                slice_gw_list = db.get_slice_gws(slice.id)
                for gateway in slice_gw_list:
                    if str(gateway.id) not in tech.gateways:
                        logger.info("Stop create ap in gateway {}".format(str(gateway.id)))
                        stop_create_ap(str(gateway.id), 'ap', slice)
                ssid = tech.ssid
                passwd = tech.password
                for gw_id in tech.gateways:
                    gw_iface = db.get_gw_interfaces(gw_id, 'wifi')
                    if not gw_iface:
                        logger.info("Stop create ap in gateway {}".format(str(gw_id)))
                        stop_create_ap(str(gw_id), 'ap', slice)
                    for itemgw in gw_iface:
                        wiface = itemgw.device
                        iface = itemgw.options["eth"]
                        if str(itemgw.options["enable"]) == "no":
                            logger.info("create-ap.yaml create")
                            create_ap = open("/opt/softway4iot/src/orch/create-ap.yaml")
                            list_doc = yaml.load(create_ap)
                            item = "services"
                            if item in list_doc:
                                services = list_doc[item]
                                if "create-ap" in services:
                                    prop = services["create-ap"]
                                if "gateway" in prop:
                                    prop["gateway"] = str(gw_id)
                                if "environment" in prop:
                                    env = prop["environment"]
                                    env[0] = "AP_SSID=" + str(ssid)
                                    env[1] = "AP_WIFI_IFACE=" + str(wiface)
                                    env[2] = "AP_INTERNET_IFACE=" + str(iface)
                                    env[3] = "AP_PASSPHRASE=" + str(passwd)
                            create_ap.close()
                            create_ap = open("/opt/softway4iot/src/orch/create-ap.yaml", "w")
                            yaml.dump(list_doc, create_ap)
                            create_ap.close()
                            logger.info("Create ap start")
                            container_id = start_create_ap(slice)
                            logger.info("Create ap running!!!")
                            itemgw.options["enable"] = str(container_id)
                            db.save_gw_interface(gw_id, 'wifi', itemgw)
                            break

            if not tech.enabled:
                logger.info("Stop create ap in gateway in all gateways")
                if not tech.gateways:
                    slice_gw_list = db.get_slice_gws(slice.id)
                    for gateway in slice_gw_list:
                        if str(gateway.id) not in tech.gateways:
                            stop_create_ap(str(gateway.id), 'ap', slice)
                else:
                    for gw_id in tech.gateways:
                        gw_iface = db.get_gw_interfaces(gw_id, 'wifi')
                        for itemgw in gw_iface:
                            if itemgw.options["enable"] != "no":
                                logger.info("Stop create ap in gateway {}".format(str(gw_id)))
                                stop_create_ap(str(gw_id), 'ap', slice)
                                itemgw.options["enable"] = "no"
                                db.save_gw_interface(gw_id, 'wifi', itemgw)


def start_create_ap(slice):
    logger.info("Create container ap start")
    stream = open("/opt/softway4iot/src/orch/create-ap.yaml", 'r')
    create_ap = yaml.safe_load(stream)
    services = create_ap["services"]
    for item in services:
        container = services[item]
        gateway_id = container["gateway"]
        dockerClient = get_docker_client(slice, gateway_id)
        docker_requisition = ClientsManager(dockerClient)
        container_list = docker_requisition.running_container_list()
        if container_list:
            for container in container_list:
                if str(container.name) == 'ap':
                    return container.id
        logger.info("Running Create AP container")
        container_id = docker_requisition.run_container(container)
        return container_id


def stop_create_ap(gw_id, container_name, slice):
    logger.info("Stop create ap container")
    gateway_id = gw_id
    dockerClient = get_docker_client(slice, gateway_id)
    docker_requisition = ClientsManager(dockerClient)
    container_list = docker_requisition.running_container_list()
    if container_list:
        for container in container_list:
            if str(container.name) == container_name:
                docker_requisition.stop_container(container_name)
                gw_iface = db.get_gw_interfaces(gateway_id, 'wifi')
                for item in gw_iface:
                    item.options["enable"] = 'no'
                    db.save_gw_interface(gateway_id, 'wifi', item)
    docker_requisition.container_prune()
