import os
import subprocess
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class GatewayComm:
    def __init__(self, id):
        """
        Init
        :param id: Id of Gateway
        """
        self.id = id

    def redirect_port(self, ip_destination, in_port, destination_port, protocol='tcp'):
        """
        Redirect port to contaniner
        :return: None
        """
        command = 'sudo iptables -t nat -A PREROUTING -p ' + str(protocol) + ' --dport ' \
                  + str(in_port) + ' -j DNAT --to-destination ' + str(ip_destination) + ':' + str(destination_port)

        os.system(command)

        self.save_iptable_rules()

    def delete_redirect_port(self, ip_destination, in_port, destination_port, protocol='tcp'):
        """
        Redirect port to contaniner
        :return: None
        """
        command = 'sudo iptables -t nat -D PREROUTING -p ' + str(protocol) + ' --dport ' \
                  + str(in_port) + ' -j DNAT --to-destination ' + str(ip_destination) + ':' + str(destination_port)

        os.system(command)

        self.save_iptable_rules()

    def add_port_container(self, container_name, bridge, gateway, ip, mac_address=None, port='eth1'):
        """
        Add port in container
        :param ip: IP to apply in container
        :param container_name: ID or name of container
        :param bridge: Bridge name
        :param port: Port inside container
        :param gateway: Gateway of network
        :return: None
        """
        if mac_address:
            command = 'sudo ovs-docker add-port ' + str(bridge) + ' ' + str(port) + ' ' + container_name + \
                      ' --ipaddress=' + ip + ' --gateway=' + gateway + ' --macaddress=' + mac_address + ' --mtu=1400'
        else:
            command = 'sudo ovs-docker add-port ' + str(bridge) + ' ' + str(port) + ' ' + container_name + \
                      ' --ipaddress=' + ip + ' --gateway=' + gateway + ' --mtu=1400'

        os.system(command)

    def del_port_container(self, container_name, bridge):
        """
        Delete port of container
        :param container_name: ID or name of container
        :param bridge: Bridge where container is connected
        :return: None
        """
        command = 'sudo ovs-docker del-ports ' + str(bridge) + ' ' + container_name

        os.system(command)

    def verify_drop_rule(self):
        """
        Verify in switch of exist drop rule
        :return: True if exist and False if not exist
        """
        command = "sudo ovs-ofctl dump-flows br-data  | cut -d',' -f 8 | grep drop"
        result = subprocess.getstatusoutput(command)[1]

        if "drop" in result:
            return True
        else:
            return False

    def add_drop_rule(self):
        """
        Add rule of drop packets
        :return:
        """
        command = "sudo ovs-ofctl add-flow br-data ip,priority=2,cookie=2,actions=DROP"
        os.system(command)

    def del_drop_rule(self):
        """
        Delete rule of drop packets
        :return:
        """
        command = "sudo ovs-ofctl del-flows br-data cookie=2/-1"
        os.system(command)

    def restore_iptable_rules(self):
        """
        Restore iptables rules
        :return:
        """
        command = "sudo iptables-restore < /opt/softway4iot/conf/iptables-save"
        os.system(command)

    def save_iptable_rules(self):
        """
        Save iptables rules in file
        :return: None
        """
        command = "sudo iptables-save > /opt/softway4iot/conf/iptables-save"
        os.system(command)
