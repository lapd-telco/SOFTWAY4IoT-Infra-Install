# SOFTWAY4IoT-F3-NetManager-gw
Instance of Network Manager in Gateway
