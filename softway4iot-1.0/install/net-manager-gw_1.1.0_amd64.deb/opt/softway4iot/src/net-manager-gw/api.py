import logging
from flask import Flask, jsonify, request

from gateway_comm import GatewayComm
from configuration import Configuration

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
app = Flask(__name__)


@app.route('/redirectport', methods=['POST'])
def redirect_port():
    """
    Redirect port to contaniner
    :return: None
    """
    ip_destination = request.json['ip_destination']
    in_port = request.json['in_port']
    destination_port = request.json['destination_port']
    protocol = request.json['protocol']

    logger.info("Request: Redirect port {} {} to {}".format(protocol, in_port, destination_port))

    id = Configuration.get("GATEWAY", "id")
    gw_comm = GatewayComm(id)
    gw_comm.redirect_port(ip_destination, in_port, destination_port, protocol)
    return jsonify({'msgs': [{'data': 'Port {} redirected'.format(destination_port)}]})


@app.route('/redirectport', methods=['DELETE'])
def delete_redirect_port():
    """
    Redirect port to contaniner
    :return: None
    """
    ip_destination = request.json['ip_destination']
    in_port = request.json['in_port']
    destination_port = request.json['destination_port']
    protocol = request.json['protocol']

    logger.info("Request: Redirect port {} {} to {}".format(protocol, in_port, destination_port))

    id = Configuration.get("GATEWAY", "id")
    gw_comm = GatewayComm(id)
    gw_comm.delete_redirect_port(ip_destination, in_port, destination_port, protocol)
    return jsonify({'msgs': [{'data': 'Port {} redirected'.format(destination_port)}]})


@app.route('/containerport', methods=['POST'])
def add_port_container():
    """
    Add port in container
    :return:
    """
    container_name = request.json['container_name']
    bridge = request.json['bridge']
    gateway = request.json['gateway']
    ip = request.json['ip']
    mac_address = request.json['mac']

    logger.info('Request: Adding IP {} in container {}'.format(ip, container_name))

    id = Configuration.get("GATEWAY", "id")
    gw_comm = GatewayComm(id)
    gw_comm.add_port_container(container_name, bridge, gateway, ip, mac_address=mac_address, port='eth1')
    return jsonify({'msgs': [{'data': 'IP add in container {}'.format(container_name)}]})


@app.route('/containerport', methods=['DELETE'])
def del_port_container():
    """
    Delete port of container
    :return:
    """
    container_name = request.json['container_name']
    bridge = request.json['bridge']

    logger.info('Request: Deleting IP of container {}'.format(container_name))

    id = Configuration.get("GATEWAY", "id")
    gw_comm = GatewayComm(id)
    gw_comm.del_port_container(container_name, bridge)
    return jsonify({'msgs': [{'data': 'Port deleted of container {}'.format( container_name)}]})


@app.route('/droprule', methods=['GET'])
def verify_drop_rule():
    """
    Verify in switch of exist drop rule
    :return: True if exist and False if not exist
    """
    id = Configuration.get("GATEWAY", "id")
    gw_comm = GatewayComm(id)
    drop = gw_comm.verify_drop_rule()
    return jsonify({'data': str(drop)})


@app.route('/droprule', methods=['POST'])
def add_drop_rule():
    """
    Add rule of drop packets
    :return:
    """
    id = Configuration.get("GATEWAY", "id")
    gw_comm = GatewayComm(id)
    gw_comm.add_drop_rule()

    logger.info("Adding DROP rule")

    return jsonify({'msgs': [{'data': 'Drop rule add'}]})


@app.route('/droprule', methods=['DELETE'])
def del_drop_rule():
    """
    Delete rule of drop packets
    :return:
    """
    id = Configuration.get("GATEWAY", "id")
    gw_comm = GatewayComm(id)
    gw_comm.del_drop_rule()

    logger.info("Deleting DROP rule")

    return jsonify({'msgs': [{'data': 'Drop rule deleted'}]})
