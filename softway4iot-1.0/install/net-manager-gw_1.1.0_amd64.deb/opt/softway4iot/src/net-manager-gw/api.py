import logging
from flask import Flask, jsonify

from gateway_comm import GatewayComm
from configuration import Configuration

logger = logging.getLogger(__name__)
app = Flask(__name__)


@app.route('/redirectport', methods=['POST'])
def redirect_port(ip_destination, in_port, destination_port, protocol):
    """
    Redirect port to contaniner
    :return: None
    """
    id = Configuration.get("GATEWAY", "id")
    gw_comm = GatewayComm(id)
    gw_comm.redirect_port(ip_destination, in_port, destination_port, protocol)
    return jsonify({'msgs': [{'data': 'Port {} redirected'.format(destination_port)}]})


@app.route('/containerport', methods=['POST'])
def add_port_container(container_name, bridge, gateway, ip):
    """
    Add port in container
    :param ip:
    :param container_name:
    :param bridge:
    :param port:
    :param gateway:
    :return:
    """
    id = Configuration.get("GATEWAY", "id")
    gw_comm = GatewayComm(id)
    gw_comm.add_port_container(container_name, bridge, gateway, ip, mac_address=None, port='eth1')
    return jsonify({'msgs': [{'data': 'IP {} add in container {}'.format(ip, container_name)}]})


@app.route('/containerport', methods=['DELETE'])
def del_port_container(container_name, bridge):
    """
    Delete port of container
    :param container_name:
    :param bridge:
    :return:
    """
    id = Configuration.get("GATEWAY", "id")
    gw_comm = GatewayComm(id)
    gw_comm.del_port_container(container_name, bridge)
    return jsonify({'msgs': [{'data': 'Port deleted of container {}'.format( container_name)}]})


@app.route('/droprule', methods=['GET'])
def verify_drop_rule():
    """
    Verify in switch of exist drop rule
    :return: True if exist and False if not exist
    """
    id = Configuration.get("GATEWAY", "id")
    gw_comm = GatewayComm(id)
    drop = gw_comm.verify_drop_rule()
    return jsonify({'data': str(drop)})


@app.route('/droprule', methods=['POST'])
def add_drop_rule():
    """
    Add rule of drop packets
    :return:
    """
    id = Configuration.get("GATEWAY", "id")
    gw_comm = GatewayComm(id)
    gw_comm.add_drop_rule()
    return jsonify({'msgs': [{'data': 'Drop rule add'}]})


@app.route('/droprule', methods=['DELETE'])
def del_drop_rule():
    """
    Delete rule of drop packets
    :return:
    """
    id = Configuration.get("GATEWAY", "id")
    gw_comm = GatewayComm(id)
    gw_comm.del_drop_rule()
    return jsonify({'msgs': [{'data': 'Drop rule deleted'}]})