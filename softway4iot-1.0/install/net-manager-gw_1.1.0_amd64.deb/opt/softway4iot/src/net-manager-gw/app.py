import logging
import os

from api import app
from flask_cors import CORS
from gateway_comm import GatewayComm

logging.getLogger('sw4iot').setLevel(logging.INFO)

FORMAT = '%(asctime)s - %(name)s - %(funcName)s - %(levelname)s - %(message)s'
logging.basicConfig(filename='/opt/softway4iot/logs/net-manager-gw.log', filemode='a', format=FORMAT)
logger = logging.getLogger('NetManSW4IoT')
logger.setLevel(logging.INFO)

if __name__ == '__main__':
    Gw = GatewayComm('')
    Gw.restore_iptable_rules()
    # Gw.restore_ip()

    cors = CORS(app, resources={r"/api/*": {"origins": "*"}})
    app.run(host='0.0.0.0', port=os.environ.get('SW4IOT_API_PORT', 5000), debug=False)
