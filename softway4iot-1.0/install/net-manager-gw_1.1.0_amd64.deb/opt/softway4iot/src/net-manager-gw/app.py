import logging
import os

from api import app
from flask_cors import CORS
from gateway_comm import GatewayComm

logging.getLogger('sw4iot').setLevel(logging.INFO)

if __name__ == '__main__':
    Gw = GatewayComm('')
    Gw.restore_iptable_rules()

    cors = CORS(app, resources={r"/api/*": {"origins": "*"}})
    app.run(host='0.0.0.0', port=os.environ.get('SW4IOT_API_PORT', 5000), debug=False)