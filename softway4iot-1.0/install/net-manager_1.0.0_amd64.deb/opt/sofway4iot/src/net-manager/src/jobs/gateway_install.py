from src.network_manager.gateway_manager import GatewayManager
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def install_gw(db):
    """
    Verify for new Installations of Gateways
    :param db: Database connection
    :return: None
    """
    gateways = db.get_new_gateways()

    logger.info("Verifying for new gateways")

    for gateway in gateways:
        logger.info("New Gateway with id: {}".format(gateway.id))

        logger.info("Setup connection between GM and Gateway with id: {}".format(gateway.id))

        gm = GatewayManager()
        gm.config_network_gateway(gateway.id, gateway.ip_address)

        logger.info("Sucessfull installed tunnel between GM and Gateway with id: {}".format(gateway.id))

        db.del_new_gateway(gateway.id)


def uninstall_gw(db):
    pass