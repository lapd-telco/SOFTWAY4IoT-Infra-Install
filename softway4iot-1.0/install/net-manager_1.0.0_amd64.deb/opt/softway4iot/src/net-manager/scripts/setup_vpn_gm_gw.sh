#!/bin/bash

ip_gm=$1
public_ip_gw=$2
id_gw=$3

sysctl -p /etc/sysctl.conf

key=`cat /opt/softway4iot/docker_certs/key`

cat >> /etc/ipsec.secrets << EOF
$ip_gm $public_ip_gw : PSK $key
EOF

cat >> /etc/ipsec.conf << EOF
# connection to Gateway$id_gw
conn gm-to-gw$id_gw
	authby=secret
	left=$ip_gm
	right=$public_ip_gw
	leftsubnet=10.249.1.0/24
	rightsubnet=10.249.$id_gw.0/24
	ike=aes256-sha2_256-modp1024!
	esp=aes256-sha2_256!
	keyingtries=0
	ikelifetime=1h
	lifetime=8h
	dpddelay=30
	dpdtimeout=120
	dpdaction=restart
	auto=start

conn gm1-to-gw$id_gw
	authby=secret
	left=$ip_gm
	right=$public_ip_gw
	leftsubnet=10.250.1.0/24
	rightsubnet=10.250.$id_gw.0/24
	ike=aes256-sha2_256-modp1024!
	esp=aes256-sha2_256!
	keyingtries=0
	ikelifetime=1h
	lifetime=8h
	dpddelay=30
	dpdtimeout=120
	dpdaction=restart
	auto=start

EOF

ipsec restart

