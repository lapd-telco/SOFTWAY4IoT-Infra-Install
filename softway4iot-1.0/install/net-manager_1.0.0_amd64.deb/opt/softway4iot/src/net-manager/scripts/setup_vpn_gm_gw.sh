#!/bin/bash

ip_gm=10.16.0.178
ip_gw=10.16.0.243
ip_gm_subnet=10.249.1.1/16
ip_gw_subnet=10.249.2.1/16
id_gw=1

sysctl -p /etc/sysctl.conf

key=`cat ./conf/key`

cat >> /etc/ipsec.secrets << EOF
$ip_gm $ip_gw : PSK $key
EOF

cat >> /etc/ipsec.conf << EOF
# connection to Gateway$id_gw
conn gm-to-gw$id_gw
	authby=secret
	left=$ip_gm
	right=$ip_gw
	ike=aes256-sha2_256-modp1024!
	esp=aes256-sha2_256!
	keyingtries=0
	ikelifetime=1h
	lifetime=8h
	dpddelay=30
	dpdtimeout=120
	dpdaction=restart
	auto=start
# ignore subnet of applications
conn ignorelan$id_gw
    left=$ip_gm #prevents usage in peers selection algorithm
    leftsubnet=$ip_gm_subnet
    rightsubnet=$ip_gw_subnet
    authby=never
    type=passthrough
    auto=route
EOF

iptables -t nat -A POSTROUTING -s $ip_gw_subnet -d $ip_gm_subnet -j MASQUERADE

ipsec restart

