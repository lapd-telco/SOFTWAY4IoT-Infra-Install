#!/bin/bash
apt update && sudo apt upgrade -y
apt install strongswan -y
apt-get install openvswitch-switch -y

# Install OVS-Docker:
cd /usr/bin
wget wget https://raw.githubusercontent.com/openvswitch/ovs/master/utilities/ovs-docker
chmod a+rwx ovs-docker
