#!/bin/bash

add_gw(){
	ip_gm=$1
	ip_gw=$2
	ip_gm_subnet=$3
	ip_gw_subnet=$4

	key=`cat ../conf/key`

	cat >> /etc/ipsec.secrets << EOF
	# source      destination
	$ip_gw $ip_gm : PSK $key
	EOF

	cat >> /etc/ipsec.conf << EOF
	# connection to Gateway1
	conn gm-to-gw1
		authby=secret
		left=$ip_gm
		right=$ip_gw
		ike=aes256-sha2_256-modp1024!
		esp=aes256-sha2_256!
		keyingtries=0
		ikelifetime=1h
		lifetime=8h
		dpddelay=30
		dpdtimeout=120
		dpdaction=restart
		auto=start
	# ignore subnet of applications
	conn ignorelan
		left=$ip_gm #prevents usage in peers selection algorithm
		leftsubnet=$ip_gm_subnet
		rightsubnet=$ip_gw_subnet
		authby=never
		type=passthrough
		auto=route
	EOF

	iptables -t nat -A POSTROUTING -s $ip_gw_subnet -d $ip_gm_subnet -j MASQUERADE
	ipsec restart

	}

del_gw(){
    echo "Deleting"
}

usage() {
	cat << EOF
	${UTIL}: Create a tunnel between Gateway Manager and Gateway.
	usage: ${UTIL} COMMAND
	Commands:
	  add-gateway IP_GM IP_GW IP_GM_SUB IP_GW_SUB
		                Configure VPN in Gateway.
		                e.g: sudo ./create_tunnel.sh add-gateway 10.16.0.138 10.16.0.280 10.250.1.1/24 10.250.1.128/24
	  del-gateway IP_GM IP_GW IP_GM_SUB IP_GW_SUB
		                Delete VPN of Gateway.
	EOF
}


if [ $# -eq 0 ]; then
    usage
    exit 0
fi

case $1 in
    "add-gateway")
        shift
        add_gw "$@"
        exit 0
        ;;
    "del-gw")
        shift
        del_port "$@"
        exit 0
        ;;
    -h | --help)
        usage
        exit 0
        ;;
    *)
        echo >&2 "Unknown command \"$1\" (use --help for help)"
        exit 1
        ;;
esac
