#!/bin/bash

gateway_manager_ip=$1
gateway_ip=$2
id_gw=$3
phy_interface=$4
user_gw=$5
user_gm=$6

gw_type=$7

subnet_data=$8
subnet_control=$9

# Copiar configuracoes para o Gateway:
scp * $user_gw@$gateway_ip:/home/$user_gw
ssh -t $user_gw@$gateway_ip "chmod +x /home/$user_gw/*"

# Limpar configuracoes antigas:
ssh -t $user_gw@$gateway_ip "sudo /home/$user_gw/clear_installation.sh"

# Configuracoes Gateway 1:
ssh -t $user_gw@$gateway_ip "sudo /home/$user_gw/initial_setup_bridges.sh $phy_interface $subnet_data $subnet_control $gw_type"
ssh -t $user_gw@$gateway_ip "sudo /home/$user_gw/add_gw.sh $gateway_manager_ip"

# Adicionar configuracoes entre Gateway Manager e Gateway 1:
ssh -t $user_gm@$gateway_manager_ip "sudo /home/$user_gm/add_gw_gm.sh gw$id_gw $gateway_ip"

