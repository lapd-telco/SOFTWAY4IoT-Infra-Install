#!/bin/bash

ip_gm=10.16.0.138
ip_gw=10.16.0.180
ip_gm_subnet=10.250.1.1/24
ip_gw_subnet=10.250.1.128/24

apt update && sudo apt upgrade -y
apt install strongswan -y

cat >> /etc/sysctl.conf << EOF
net.ipv4.ip_forward = 1
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
EOF

sysctl -p /etc/sysctl.conf

scp labora@$ip_gm:/opt/SOFTWAY4IoT-NetManager/conf/key key.txt

cat >> ipsec.conf << EOF
# basic configuration
config setup
        charondebug="all"
        uniqueids=yes
        strictcrlpolicy=no
EOF

cp ipsec.conf /etc/ipsec.conf
rm ipsec.conf

key=`cat key.txt`

rm key.txt

cat >> /etc/ipsec.secrets << EOF
$ip_gm $ip_gw : PSK $key
EOF

cat >> /etc/ipsec.conf << EOF

# connection to Gateway1

conn gm-to-gw1
	authby=secret
	left=$ip_gw
	right=$ip_gm
	ike=aes256-sha2_256-modp1024!
	esp=aes256-sha2_256!
	keyingtries=0
	ikelifetime=1h
	lifetime=8h
	dpddelay=30
	dpdtimeout=120
	dpdaction=restart
	auto=start
# ignore subnet of applications
conn ignorelan
    left=$ip_gw #prevents usage in peers selection algorithm
    leftsubnet=$ip_gw_subnet
    rightsubnet=$ip_gm_subnet
    authby=never
    type=passthrough
    auto=route
EOF

iptables -t nat -A POSTROUTING -s $ip_gm_subnet -d $ip_gw_subnet -j MASQUERADE

ipsec restart