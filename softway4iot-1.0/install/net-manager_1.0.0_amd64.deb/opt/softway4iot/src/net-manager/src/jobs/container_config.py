import ast
import random
import logging

from sw4iotdatabase.schemas import ActionSchema
from sw4iotdatabase.models import ActionModel
# from src.network_manager.gateway import Gateway
from src.network_manager.gateway_manager import GatewayManager

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def select_ip():
    """
    Select IP
    :return:
    """
    number = random.randint(10, 252)
    ip = '10.249.1.' + str(number) + '/24'
    return ip


def container_net(db):
    """
    Add network in conatiner
    :param db: Database connection
    :return: None
    """
    slices = db.get_slices()
    for slice in slices:
        slice.enabled = db.get_slice_enabled(slice.id)
        if slice.enabled:
            apps = db.get_slice_apps(slice.id)

            for app in apps:
                apps_status = db.get_slice_app_status(slice.id, app.id)

                if apps_status is None:
                    continue

                if apps_status.phase != 'Running' and apps_status.phase != 'Terminated':
                    containers = ast.literal_eval(apps_status.message)

                    logger.info("Applying Network in containers")

                    ips = {}
                    indice = 0

                    for container in containers:
                        container_id = containers[container]
                        gm = GatewayManager()
                        ip = select_ip()
                        gm.add_network_in_container(container_id, ip)

                        ips[indice] = ip
                        indice += 1

                        logger.info("IP {} applyied in container {}".format(container_id, ip))

                    logger.info("Network setup complete")

                    apps_status.phase = 'Running'
                    apps_status.pod_ip = str(ips)

                    db.save_slice_app_status(slice.id, app.id, apps_status)


def delete_container_net(db):
    """
    Delete network in container
    :param db: Database connection
    :return: None
    """
    slices = db.get_slices()
    for slice in slices:
        slice.enabled = db.get_slice_enabled(slice.id)
        if slice.enabled:
            apps = db.get_slice_apps(slice.id)
            for app in apps:
                action_app = db.get_slice_app_action(slice.id, app.id)
                if action_app and action_app.action == 'terminated':

                    logger.info("Deleting IP of containers stopped")

                    apps_status = db.get_slice_app_status(slice.id, app.id)
                    containers = ast.literal_eval(apps_status.message)
                    for container in containers:
                        container_id = containers[container]
                        gm = GatewayManager()
                        gm.del_network_in_container(container_id)

                    db.save_slice_app_action(slice.id, app.id, ActionSchema().load(ActionModel(action='delete').to_dict()))
                    db.delete_slice_app(slice.id, app.id)