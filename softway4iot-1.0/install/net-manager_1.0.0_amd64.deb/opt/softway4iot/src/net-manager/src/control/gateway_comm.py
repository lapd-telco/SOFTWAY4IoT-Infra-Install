from src.comm.ovsctl import OvsCtl
from src.comm.ssh_comm import SSH2Connect


class GatewayComm:
    def __init__(self, ip_address, user, ssh_port, key_filename, password, phy_interface, remote_ip=None,
                 is_raspberry=False):
        """

        :param ip_address:
        :param user:
        :param ssh_port:
        :param key_filename:
        :param password:
        :param is_raspberry:
        """
        self.ip = ip_address
        self.user = user
        self.port = ssh_port
        self.key_filename = key_filename
        self.password = password
        self.phy_interface = phy_interface
        self.remote_ip = remote_ip
        self.is_raspberry = is_raspberry

        self.ovs = OvsCtl(self.ip)

    def add_ovs_bridge(self, bridge_name):
        """
        Add bridge in OVS
        :param bridge_name:
        :return:
        """
        self.ovs.add_br(bridge_name)

    def delete_ovs_bridge(self, bridge_name):
        """
        Delete bridge in OVS
        :param bridge_name: name of bridge
        :return:
        """
        self.ovs.del_bridge(bridge_name)

    def add_ovs_port(self, port_name, bridge_name):
        """
        Add port in OVS
        :param port_name:
        :param bridge_name:
        :return:
        """
        self.ovs.add_internal_port(bridge_name, port_name)

    def del_ovs_port(self, port_name, bridge_name):
        """
        Delete port in OVS
        :param port_name:
        :param bridge_name:
        :return:
        """
        pass

    def add_vxlan_port(self, br_name, name_vxlan):
        """
        Add vlan port in OVS
        :param br_name: Bridge name
        :param name_vxlan: Name of vlan port
        :param remote_ip: IP address of remote host
        :return:
        """
        self.ovs.add_vxlan_port(br_name, name_vxlan, self.remote_ip)

    def add_gre_port(self,  br_name, name_vxlan):
        """

        :param br_name:
        :param name_vxlan:
        :param remote_ip:
        :return:
        """
        self.ovs.add_gre_port(br_name, name_vxlan, self.remote_ip)

    def set_ip_in_interface(self, interface, ip):
        """
        Add IP in port
        :param interface: interface name
        :param ip: ip to apply in interface
        :return:
        """
        command = 'sudo ifconfig ' + interface + ' ' + ip
        SSH2Connect().run_command(self.ip, self.user, self.port, self.key_filename, command, self.password)

    def add_more_threads(self):
        """
        Add more threads in OVS --used in raspberry
        :return:
        """
        command = 'sudo ovs-vsctl set Open_vSwitch $(ovs-vsctl show | head -n 1) other_config:n-handler-threads=13'
        SSH2Connect().run_command(self.ip, self.user, self.port, self.key_filename, command, self.password)

    def set_remote_ip(self, remote_ip):
        self.remote_ip = remote_ip

    def add_of_rule(self):
        """

        :return:
        """
        pass

    def configure_nat(self, interface, ip):
        """

        :return:
        """
        command = 'sudo sh -c \"echo \'1\' > /proc/sys/net/ipv4/ip_forward\"'
        SSH2Connect().run_command(self.ip, self.user, self.port, self.key_filename, command, self.password)

        command = 'sudo iptables -t nat -A POSTROUTING -o ' + self.phy_interface + ' -s ' + ip + ' ! -d ' + ip \
                  + ' -j MASQUERADE'
        SSH2Connect().run_command(self.ip, self.user, self.port, self.key_filename, command, self.password)

        command = 'sudo iptables -A FORWARD -d' + ip + ' -i ' + self.phy_interface + ' -o ' + interface + \
                  ' -m state --state RELATED,ESTABLISHED -j ACCEPT'

        SSH2Connect().run_command(self.ip, self.user, self.port, self.key_filename, command, self.password)

        command = 'sudo iptables -A FORWARD -s ' + ip + ' -i ' + interface + ' -j ACCEPT'

        SSH2Connect().run_command(self.ip, self.user, self.port, self.key_filename, command, self.password)

    def add_ip_container(self, container_name, bridge, port, gateway, ip, mac_address=None):
        """
        Add IP address in container
        :param ip:
        :param container_name:
        :param bridge:
        :param port:
        :param gateway:
        :return:
        """
        if mac_address:
            command = 'sudo ovs-docker add-port ' + str(bridge) + ' ' + str(port) + ' ' + container_name + \
                      ' --ipaddress=' + ip + ' --gateway=' + gateway + ' --macaddress=' + mac_address + ' --mtu=1400'
        else:
            command = 'sudo ovs-docker add-port ' + str(bridge) + ' ' + str(port) + ' ' + container_name + \
                      ' --ipaddress=' + ip + ' --gateway=' + gateway + ' --mtu=1400'

        SSH2Connect().run_command(self.ip, self.user, self.port, self.key_filename, command, self.password)
