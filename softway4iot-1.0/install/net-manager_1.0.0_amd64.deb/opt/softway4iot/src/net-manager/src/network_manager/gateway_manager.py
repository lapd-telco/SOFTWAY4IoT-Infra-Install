from src.control.gateway_manager_comm import GatewayManagerComm
from src.utils.configuration import Configuration


class GatewayManager:
    def __init__(self):

        self.ip_address = Configuration.get('GATEWAYMANAGER', 'ip_gm')

        self.gateway_bridge_data = Configuration.get('GATEWAYMANAGER', 'gw_br_data')
        self.gateway_bridge_control = Configuration.get('GATEWAYMANAGER', 'gw_br_control')

        self.name_bridge_data = Configuration.get('GATEWAYMANAGER', 'name_bridge_data')
        self.name_bridge_control = Configuration.get('GATEWAYMANAGER', 'name_bridge_control')

        self.name_port_bridge_data = Configuration.get('GATEWAYMANAGER', 'name_port_bridge_data')
        self.name_port_bridge_control = Configuration.get('GATEWAYMANAGER', 'name_port_bridge_control')

        self.name_port_vxlan_data = Configuration.get('GATEWAYMANAGER', 'name_port_vxlan_data')
        self.name_port_gre_control = Configuration.get('GATEWAYMANAGER', 'name_port_gre_control')

        self.ip_br_data = Configuration.get('GATEWAYMANAGER', 'ip_br_data')
        self.ip_br_control = Configuration.get('GATEWAYMANAGER', 'ip_br_control')

        self.phy_interface = Configuration.get('GATEWAYMANAGER', 'phy_interface')

        self.control = GatewayManagerComm(self.phy_interface)

    def set_configs(self):
        """
        TODO
        Read information in database of network
        :return:
        """

    def add_network_in_container(self, container_name, static_ip, bridge='br-data'):
        """

        :param container_name: Name of container
        :param bridge: Name of bridge of connection
        :param port: Port name to create in container
        :param static_ip: IP address if static
        :return:
        """
        gateway = self.gateway_bridge_control if bridge == self.name_bridge_control else self.gateway_bridge_data
        self.control.add_port_container(container_name, bridge, gateway, static_ip)

    def del_network_in_container(self, container_name, bridge='br-data'):
        """

        :param container_name:
        :param bridge:
        :return:
        """
        self.control.del_port_container(container_name, bridge)

    def config_network_gateway(self, gateway_id, gateway_ip):
        """
        Configure VPN connection with Gateway
        :param gateway_id:
        :param gateway_ip:
        :return:
        """

        self.control.setup_vpn(gateway_id, gateway_ip, self.ip_address)

        # self.control.add_gre_port_tunnel(gateway_id, gateway_ip)
        # self.control.add_vxlan_port_tunnel(gateway_id, gateway_ip)

    def verify_drop_rule(self):
        """
        Verify if exist drop rule in ovs
        :return:
        """
        return self.control.verify_drop_rule()

    def add_nat_rule(self, bridge='br-data'):
        """
        TODO
        :return:
        """
        self.control.add_drop_rule()

    def del_nat_rule(self,  bridge='br-data'):
        """
        TODO
        :return:
        """
        self.control.del_drop_rule()

    def restore_iptables_rules(self):
        """
        Restore iptables rules
        :return:
        """
        self.control.restore_iptable_rules()