class Gateway:
    def add_gateway(self):
        pass

    def del_gateway(self):
        pass
