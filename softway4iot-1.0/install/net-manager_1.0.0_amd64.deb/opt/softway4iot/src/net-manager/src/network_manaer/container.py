class Container:
    def add_container(self):
        pass

    def del_container(self):
        pass
