import os
import subprocess
from src.comm.ovsctl import OvsCtl


class GatewayManagerComm:
    def __init__(self, phy_interface):
        """

        :param phy_interface: Physical Interface
        """
        self.phy_interface = phy_interface
        self.ovs = OvsCtl('localhost')

    def add_of_rule(self):
        """

        :return:
        """
        pass

    def redirect_port(self, interface, ip_destination, in_port, destination_port, protocol='tcp'):
        """
        TODO
        :return:
        """
        command = 'sudo iptables -t nat -A PREROUTING -p '+ str(protocol) + ' --dport ' \
                  + str(in_port) +' -j DNAT --to-destination '+ '10.249.1.4'+':' + str(destination_port)

        os.system(command)

    def add_port_container(self, container_name, bridge, gateway, ip, mac_address=None, port='eth1'):
        """
        Add port in container
        :param ip:
        :param container_name:
        :param bridge:
        :param port:
        :param gateway:
        :return:
        """
        if mac_address:
            command = 'sudo ovs-docker add-port ' + str(bridge) + ' ' + str(port) + ' ' + container_name + \
                      ' --ipaddress=' + ip + ' --gateway=' + gateway + ' --macaddress=' + mac_address + ' --mtu=1400'
        else:
            command = 'sudo ovs-docker add-port ' + str(bridge) + ' ' + str(port) + ' ' + container_name + \
                      ' --ipaddress=' + ip + ' --gateway=' + gateway + ' --mtu=1400'

        os.system(command)

    def del_port_container(self, container_name, bridge):
        """
        Delete port of container
        :param ip:
        :param container_name:
        :param bridge:
        :param port:
        :param gateway:
        :return:
        """
        command = 'sudo ovs-docker del-ports ' + str(bridge) + ' ' + container_name

        os.system(command)

    def add_gre_port_tunnel(self, gateway_id, gateway_ip):
        """

        :return:
        """
        command = "ovs-vsctl add-port br-data gre_gw_" + str(gateway_id) + " -- set Interface gre_gw_" + \
                  str(gateway_id) + " type=gre options:remote_ip=" + str(gateway_ip)

        os.system(command)

    def add_vxlan_port_tunnel(self, gateway_id, gateway_ip):
        """

        :return:
        """
        command = "ovs-vsctl add-port br-control vxlan_gw_" + str(gateway_id) + " -- set Interface vxlan_gw_" + \
                  str(gateway_id) + " type=vxlan options:remote_ip=" + str(gateway_ip)

        os.system(command)

    def verify_drop_rule(self):
        """
        Verify in switch of exist drop rule
        :return: True if exist and False if not exist
        """
        command = "sudo ovs-ofctl dump-flows br-data  | cut -d',' -f 8 | grep drop"
        result = subprocess.getstatusoutput(command)[1]

        if "drop" in result:
            return True
        else:
            return False

    def add_drop_rule(self):
        """

        :return:
        """
        command = "sudo ovs-ofctl add-flow br-data ip,priority=2,cookie=2,actions=DROP"
        os.system(command)

    def del_drop_rule(self):
        """

        :return:
        """
        command = "sudo ovs-ofctl del-flows br-data cookie=2/-1"
        os.system(command)

    def restore_iptable_rules(self):
        """

        :return:
        """
        command = "sudo iptables-restore < /opt/softway4iot/conf/iptables-save"
        os.system(command)

    def save_iptable_rules(self):
        command = "sudo iptables-save > /opt/softway4iot/conf/iptables-save"
        os.system(command)

    def setup_vpn(self, id_gateway, gateway_ip, ip_gateway_manager):
        command = "sudo /opt/softway4iot/src/net-manager/scripts/setup_vpn_gm_gw.sh " + str(ip_gateway_manager) + \
                  " " + str(gateway_ip) + " " + str(id_gateway)

        os.system(command)