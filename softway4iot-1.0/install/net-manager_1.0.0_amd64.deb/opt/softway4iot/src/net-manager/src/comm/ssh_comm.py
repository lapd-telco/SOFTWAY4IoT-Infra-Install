import paramiko
import logging

logging.getLogger("paramiko").setLevel(logging.WARNING)


class SSH2Connect:

    def __init__(self):
        pass

    def run_command(self, address, user, port, key_filename, command, password='l@b0r@1NF'):
        try:

            client = paramiko.SSHClient()

            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

            client.connect(hostname=address, username=user, port=port, key_filename=key_filename)
            stdin, stdout, stderr = client.exec_command(command, get_pty=True)
            stdin.write(password + '\n')
            stdin.flush()
            print(stdout.read())
            print("Exit status from ssh server: %d" % (stdout.channel.recv_exit_status()))

            client.close()

        except Exception:
            print("Error in the ssh2 connection: ")
