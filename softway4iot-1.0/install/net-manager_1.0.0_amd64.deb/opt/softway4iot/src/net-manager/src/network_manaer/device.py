class Device:
    def add_device(self):
        pass

    def del_device(self):
        pass
