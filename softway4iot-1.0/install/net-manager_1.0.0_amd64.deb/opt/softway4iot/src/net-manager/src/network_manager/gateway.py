from src.control.gateway_comm import GatewayComm
from src.network_manager.container import Container
from src.utils.configuration import Configuration


class Gateway:
    def __init__(self, id, ip_address, user, port, key_filename, password, phy_interface, remote_ip, is_raspberry):
        """

        :param id: ID of gateway
        :param ip_address: IP address of gateway
        :param user: user of gateway
        :param port: ssh port
        :param key_filename: ssh key
        :param password: password of user
        :param phy_interface: physical interface of gateway
        :param remote_ip: ip of Gateway Manager
        :param is_raspberry: if gateways is Raspberry
        """
        self.control = GatewayComm(ip_address, user, port, key_filename, password, phy_interface, remote_ip, is_raspberry)
        self.id = id
        self.ip_address = ip_address

        self.gateway_bridge_data = Configuration.get('GATEWAY', 'ip_prefix_br_data') + str(id) + '.1'
        self.gateway_bridge_control = Configuration.get('GATEWAY', 'ip_prefix_br_control') + str(id) + '.1'

        self.name_bridge_data = Configuration.get('GATEWAY', 'name_bridge_data')
        self.name_bridge_control = Configuration.get('GATEWAY', 'name_bridge_control')

        self.name_port_bridge_data = Configuration.get('GATEWAY', 'name_port_bridge_data')
        self.name_port_bridge_control = Configuration.get('GATEWAY', 'name_port_bridge_control')

        self.name_port_vxlan_data = Configuration.get('GATEWAY', 'name_port_vxlan_data')
        self.name_port_gre_control = Configuration.get('GATEWAY', 'name_port_vxlan_control')

        self.ip_br_data = Configuration.get('GATEWAY', 'ip_prefix_br_data') + str(self.id + 1) + '.1/16'
        self.ip_br_control = Configuration.get('GATEWAY', 'ip_prefix_br_control') + str(self.id + 1) + '.1/16'

    def set_configs(self):
        """
        TODO
        Read information in database of network
        :return:
        """

    def initial_configuration(self):
        """
        Setup initial configuration on Gateways
        :return:
        """
        self.clean_installation()

        if self.control.is_raspberry:
            self.control.add_more_threads()

        # Configure params in Data bridge

        self.control.add_ovs_bridge(self.name_bridge_data)
        self.control.add_ovs_port(self.name_port_bridge_data, self.name_bridge_data)
        self.control.set_ip_in_interface(self.name_port_bridge_data, self.ip_br_data)

        self.control.configure_nat(self.name_port_bridge_data, self.ip_br_data)

        # Configure params in Control bridge

        self.control.add_ovs_bridge(self.name_bridge_control)
        self.control.add_ovs_port(self.name_port_bridge_control, self.name_bridge_control)
        self.control.set_ip_in_interface(self.name_port_bridge_control, self.ip_br_control)

        self.control.configure_nat(self.name_port_bridge_control, self.ip_br_control)

    def clean_installation(self):
        """
        Clean old installation in Gateway Manager
        :return:
        """
        self.control.delete_ovs_bridge(self.name_bridge_data)
        self.control.delete_ovs_bridge(self.name_bridge_control)

    def configure_gw_gm(self):
        """
        Add new Gateway in Gateway Manager
        :return:
        """
        self.control.add_gre_port(self.name_bridge_data, self.name_port_vxlan_data)
        self.control.add_vxlan_port(self.name_bridge_control, self.name_port_gre_control)

    def add_network_in_container(self, container_name, bridge, port, static_ip=None):
        """
        :param container_name: Name of container
        :param bridge: Name of bridge of connection
        :param port: Port name to create in container
        :param static_ip: IP address if static
        :return:
        """
        new_container = Container()

        gateway = self.gateway_bridge_control if bridge == self.name_bridge_control else self.gateway_bridge_data

        if static_ip:
            self.control.add_ip_container(container_name, bridge, port, gateway, static_ip)
        else:
            mac_address = new_container.generate_mac_address()
            ip_dhcp = new_container.make_dhcp_request(mac_address, self.name_bridge_control)
            self.control.add_ip_container(container_name, bridge, port, gateway, ip_dhcp, mac_address)

    def configure_vpn_gateway(self):
        """

        :return:
        """
        pass

    def add_nat_rule(self):
        """

        :return:
        """
        pass
