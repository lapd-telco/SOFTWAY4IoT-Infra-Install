import logging

from scapy.layers.dhcp import BOOTP, DHCP, DHCPRevOptions
from scapy.layers.inet import IP, UDP
from scapy.layers.l2 import Ether
from scapy.sendrecv import srp1
from scapy.utils import mac2str
from scapy.volatile import RandInt

logger = logging.getLogger(__name__)


class Container:
    def __init__(self):
        pass

    def make_dhcp_request(self, device_mac, local_iface):
        """
        Make a DHCP Request to server and receive a IP address to device
        :param device_mac: mac address of device
        :param local_iface: interface
        :type device_mac: str
        :type local_iface: str
        """

        # build dhcp discover packet
        dhcp_discover = Ether(src=device_mac, dst='ff:ff:ff:ff:ff:ff') \
                        / IP(src='0.0.0.0', dst='10.250.255.255') \
                        / UDP(dport=67, sport=68) \
                        / BOOTP(chaddr=mac2str(device_mac), xid=RandInt()) \
                        / DHCP(options=[('message-type', 'discover'),
                                        ("param_req_list",
                                         DHCPRevOptions["subnet_mask"][0],
                                         DHCPRevOptions["router"][0],
                                         DHCPRevOptions["name_server"][0],
                                         DHCPRevOptions["domain"][0],
                                         DHCPRevOptions["lease_time"][0]),
                                        DHCPRevOptions["renewal_time"][0],
                                        'end'])
        # send dhcp discover packet
        dhcp_offer = srp1(dhcp_discover, iface=local_iface, timeout=5)
        if not dhcp_offer:
            logger.info("DHCP offer error of deive {}".format(device_mac))
            return

        # Set dhcp request fields
        myip = dhcp_offer[BOOTP].yiaddr
        sip = dhcp_offer[BOOTP].siaddr
        xid = dhcp_offer[BOOTP].xid
        # build dhcp request packet
        dhcp_request = Ether(src=device_mac, dst="ff:ff:ff:ff:ff:ff") \
                       / IP(src="0.0.0.0", dst="10.250.255.255") \
                       / UDP(sport=68, dport=67) / BOOTP(chaddr=mac2str(device_mac), xid=xid) \
                       / DHCP(options=[('message-type', 'request'),
                                       ("server_id", sip),
                                       ("requested_addr", myip),
                                       ("param_req_list",
                                        DHCPRevOptions["subnet_mask"][0],
                                        DHCPRevOptions["router"][0],
                                        DHCPRevOptions["name_server"][0],
                                        DHCPRevOptions["domain"][0],
                                        DHCPRevOptions["lease_time"][0]),
                                       DHCPRevOptions["renewal_time"][0],
                                       "end"])
        # call dhcp request & wait receive the ip_address, until timeout
        dhcp_ack = srp1(dhcp_request, iface=local_iface, timeout=5)
        dhcp_type = next(
            opt[1] for opt in dhcp_ack[DHCP].options if isinstance(opt, tuple) and opt[0] == 'message-type')
        if dhcp_type is not 5:
            return None
        else:
            return myip

    def generate_mac_address(self):
        """
        Generate new MAC Address to container
        :return:
        """
        mac = 'd6:56:78:3d:77:ee'

        return mac
