## Instalação manual

Requisitos para essa instalação:

- OpenVswitch
- Docker
- OVSDocker

A instalação no Raspberry pode ser feita seguindo os seguintes passos:

https://github.com/LABORA-INF-UFG/SOFTWAY4IoT-Testes/tree/master/Documentaion

#### 1 - Faça download dos arquivos desta pasta para seu computador

#### 2 - Dê permissão aos scripts:

```python
chmod +x ./*
```

#### 3 - Instalação do Gateway Manager

Execute o script ./manual_installation_gm.sh passando os seguintes parâmetros:

```bash
./manual_installation_gm.sh ip_gateway_manager physical_interface_gm user_gm subnet_data subnet_control
```

Exemplo:


```bash
./manual_installation_gm.sh 10.16.0.149 enp0s3 labora 10.249.1.1/16 10.250.1.1/16

```

#### 4 - Adicionando um novo gateway

```bash
./manual_installation_gw.sh ip_gateway_manager ip_gateway id_gateway physical_interface user_gw user_gm type_gw subnet_data subnet_control
```

Onde, o tipo do gateway pode ser 1 para **rasp** ou 0 para **pc**.

Exemplo:

```bash
./manual_installation_gw.sh 10.16.0.149 10.16.0.178 1 enp0s3 pi labora 1 10.249.2.1/16 10.250.2.1/16

```

Obs: A configuração de IPs segue da seguinte forma:

A faixa 10.249.**y**.**x**/24 é usada para a comunicação de dados, 
A faixa 10.250.**y**.**x**/24 é usada para a comunicação de controle.

A faixa 10.249.1.1 - 10.249.127.249 é reservada para as aplicaçes.
A faixa 10.250.1.1 - 10.250.127.249 é reservada para as aplicaçes.

A faixa 10.249.128.1 - 10.249.249.249 é distribuída pela servidor DHCP.
A faixa 10.250.128.1 - 10.250.249.249 é distribuída pela servidor DHCP.

#### 5 - Adicionar um novo container:

Ao adicionar um novo container, adicione o parâmetro **--net=none** na execuação.

O seguinte container pode ser executado para testes de rede:

```bash
sudo docker run -it --net=none --name=container12 amouat/network-utils

```

#### 6 - Adcionar conectividade a um container:

Conexão entre os containers:

```bash
sudo ovs-docker add-port br-data eth02 container12 --ipaddress=10.250.1.2/16 --gateway=10.250.1.1 --mtu=1400

```
Obs: os containers inicialmente não possuem acesso à Internet. A liberação da Internet pode ser realizada no próximo passo.

Acesso a internet:
```bash
sudo ovs-ofctl add-flow br-data ip,nw_src=10.250.1.2,priority=8,actions=NORMAL
sudo ovs-ofctl add-flow br-data ip,nw_dst=10.250.1.2,priority=8,actions=NORMAL
```


Obs: o MTU usado para comunicação entre os containers é de 1400, devido ao encapsulamento VXLAN.
