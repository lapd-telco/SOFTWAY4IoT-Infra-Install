import hashlib
import logging
import os
import platform
import socket
from typing import List

import requests
import yaml

logger = logging.getLogger(__name__)

# Static variables
MACHINE_X86 = ["x86_64"]  # type: List[str]
MACHINE_ARM = ["armv7l"]  # type: List[str]
WLAN_PREFIX = 'wlans_'  # type: str


def is_arm():
    """
    Is a ARM machine

    :rtype: bool
    :return: True if is a ARM machine, otherwise, False
    """
    return getinfo()['machine'] in MACHINE_ARM


def is_x86():
    """
    Is a x86 machine

    :rtype: bool
    :return: True if is a x86 machine, otherwise, False
    """
    return getinfo()['machine'] in MACHINE_X86


def clean_str(txt):
    """
    Clear text removing the spaces

    :param txt: Text content
    :return: Text cleared
    """
    return txt.replace(' ', '').lower()


def short_hash(txt, length=6):
    """
    Short hash from text

    :param txt: Text to create a short hash
    :param length: Size of the hash
    :type txt: str
    :type length: int
    :rtype: str
    :return: Short hash
    """
    hash = hashlib.sha1()
    hash.update(str(clean_str(txt)).encode('utf8'))
    return hash.hexdigest()[:length]


def getnodename():
    """
    Get the hostname

    :rtype: str
    :return: Hostname
    """
    return socket.gethostname()


def getip():
    """
    IP address of hostname

    :rtype: str
    :return: IP address
    """
    return [(s.connect(('8.8.8.8', 53)), s.getsockname()[0], s.close()) for s in
            [socket.socket(socket.AF_INET, socket.SOCK_DGRAM)]][0][1]


def getinfo():
    """
    Machine information (architecture, machine, ...)

    :rtype: dict
    :return: Machine information
    """
    sys_name, node_name, release, version, machine = os.uname()
    return {
        'architecture': platform.architecture()[0],
        'machine': machine,
        'node_name': node_name,
        'release': release,
        'sys_name': sys_name,
        'version': version
    }


def format_vxlan_port_name(remote_ip):
    """
    Format vxlan to 'vxifIPADDRESS'

    :param remote_ip: IP address
    :type remote_ip: str
    :rtype: str
    :return: Formatted vxlan name
    """
    return "vxif{}".format(remote_ip.replace('.', ''))


def get_yaml_content(url):
    """
    Get the yaml from a URL

    :param url: URL of a yaml file
    :type url: str
    :rtype: str
    :return: Content of yaml file
    """
    try:
        r = requests.get(url)
        if r.status_code == 200:
            return yaml.load(r.content)
    except Exception as e:
        logger.error(e)
    return None
