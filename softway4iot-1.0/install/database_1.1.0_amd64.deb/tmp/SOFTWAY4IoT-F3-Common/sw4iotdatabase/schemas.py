import uuid
from datetime import datetime

from dateutil.tz import tzutc
from marshmallow import Schema, fields, post_load, validate

from sw4iotdatabase import validation
from sw4iotdatabase.models import SliceModel, LoraModel, ZigbeeModel, WifiModel, DeviceModel, SecurityModel, \
    SliceNetModel, \
    InterfaceModel, GatewayInfoModel, GatewayModel, SliceConnectionModel, VethPeerLinkModel, PatchModel, \
    DefaultNetConfigModel, LocationModel, ActionModel, StatusModel, SimpleDeviceModel, NetDeviceModel, UpdatedAtModel, \
    AppModel, NRFModel, AppStatusModel, VirtualInterfaceModel, NewGatewayModel, TokenGatewayInstallModel, UserModel,\
    RevokedTokenModel
from sw4iotdatabase.utils import short_hash


class ActionSchema(Schema):
    action = fields.Str(required=True)
    updated_at = fields.DateTime(allow_none=True)

    @post_load
    def make_model(self, data):
        if not data.get('updated_at'):
            data['updated_at'] = datetime.now(tzutc())
        return ActionModel(**data)


class StatusSchema(Schema):
    status = fields.Str(required=True)
    msg = fields.Str(allow_none=True)
    updated_at = fields.DateTime(allow_none=True)

    @post_load
    def make_model(self, data):
        if not data.get('updated_at'):
            data['updated_at'] = datetime.now(tzutc())
        return StatusModel(**data)


class SliceNetSchema(Schema):
    tenant = fields.Str()
    network = fields.Str()
    group = fields.Str()
    nat_policy = fields.Str()
    subnet = fields.Str()
    gateway = fields.Str()
    netmask = fields.Str()
    dns = fields.Str()

    @post_load
    def make_slice(self, data):
        return SliceNetModel(**data)


class SliceSchema(Schema):
    id = fields.Str(dump_only=True)
    name = fields.Str(required=True, validate=validate.Length(min=6))
    description = fields.Str(validate=validate.Length(min=6))
    # additional attributes
    vlan = fields.Int(dump_only=True)
    net = fields.Nested(SliceNetSchema, dump_only=True)
    enabled = fields.Bool(dump_only=True)
    action = fields.Nested(ActionSchema, dump_only=True)
    status = fields.Nested(StatusSchema, dump_only=True)
    released = fields.Bool(dump_only=True)

    @post_load
    def make_slice(self, data):
        if not 'id' in data:
            data['id'] = short_hash(str(uuid.uuid4()))
        if not 'enabled' in data or not data['enabled']:
            data['enabled'] = False
        return SliceModel(**data)


class SliceGwSchema(Schema):
    id = fields.Str()


class SliceUpdateSchema(Schema):
    name = fields.Str(validate=validate.Length(min=6))
    description = fields.Str(required=True, validate=validate.Length(min=6))


class GatewayInfoSchema(Schema):
    machine = fields.Str()
    node_name = fields.Str()
    release = fields.Str()
    sys_name = fields.Str()
    version = fields.Str()
    ip = fields.Str()
    architecture = fields.Str()

    @post_load
    def make_model(self, data):
        return GatewayInfoModel(**data)


class LocationSchema(Schema):
    latitude = fields.Str(required=True)
    longitude = fields.Str(required=True)

    @post_load
    def make_model(self, data):
        return LocationModel(**data)


class GatewayUpdateSchema(Schema):
    location = fields.Nested(LocationSchema, allow_none=True)
    description = fields.Str(validate=validate.Length(min=6), allow_none=True)
    enabled = fields.Boolean()


class GatewaySchema(GatewayUpdateSchema):
    id = fields.Str()
    name = fields.Str()
    info = fields.Nested(GatewayInfoSchema, allow_none=True)

    @post_load
    def make_model(self, data):
        return GatewayModel(**data)


class ContainerSchema(Schema):
    id = fields.Str()
    name = fields.Str()
    mac = fields.Str()


class DriverApp(Schema):
    app_id = fields.Str(required=True)


class TechSchema(Schema):
    enabled = fields.Boolean(required=True)
    updated_at = fields.DateTime()
    hash = fields.Str(dump_only=True)
    statuses = fields.List(fields.Dict, dump_only=True, allow_none=True)


class LoraSchema(TechSchema, DriverApp):
    @post_load
    def make_slice(self, data):
        if not data.get('updated_at'):
            data['updated_at'] = datetime.now(tzutc())
        return LoraModel(**data)


class ZigbeeSchema(TechSchema, DriverApp):
    @post_load
    def make_slice(self, data):
        if not data.get('updated_at'):
            data['updated_at'] = datetime.now(tzutc())
        return ZigbeeModel(**data)


class NRFSchema(TechSchema, DriverApp):
    @post_load
    def make_slice(self, data):
        if not data.get('updated_at'):
            data['updated_at'] = datetime.now(tzutc())
        return NRFModel(**data)


class WifiSchema(TechSchema):
    password = fields.Str(required=True, validate=validate.Length(min=8, max=63))
    gateways = fields.List(fields.Str, allow_none=True, default=[])
    ssid = fields.Str(dump_only=True)
    channel = fields.Int(dump_only=True)
    security = fields.Str(dump_only=True)

    @post_load
    def make_slice(self, data):
        if not data.get('updated_at'):
            data['updated_at'] = datetime.now(tzutc())
        if not data.get('gateways'):
            data['gateways'] = []
        return WifiModel(**data)


class SecuritySchema(Schema):
    enabled = fields.Boolean(required=True)

    @post_load
    def make_slice(self, data):
        if not data.get('updated_at'):
            data['updated_at'] = datetime.now(tzutc())
        return SecurityModel(**data)


class InterfaceSchema(Schema):
    type = fields.Str()
    name = fields.Str()
    device = fields.Str()
    manufacturer = fields.Str()
    max_vnets = fields.Int()
    product = fields.Str(allow_none=True)
    vid = fields.Int(allow_none=True)
    pid = fields.Int(allow_none=True)
    hwid = fields.Str(allow_none=True)
    options = fields.Dict(allow_none=True)
    updated_at = fields.DateTime(allow_none=True)

    @post_load
    def make_slice(self, data):
        if not data.get('updated_at'):
            data['updated_at'] = datetime.now(tzutc())
        return InterfaceModel(**data)


class VirtualInterfaceSchema(Schema):
    name = fields.Str()
    slice = fields.Str()
    updated_at = fields.DateTime(allow_none=True)

    @post_load
    def make_slice(self, data):
        if not data.get('updated_at'):
            data['updated_at'] = datetime.now(tzutc())
        return VirtualInterfaceModel(**data)


class VethPeerLinkSchema(Schema):
    veth0 = fields.Str(validate=validate.Length(max=15))
    veth1 = fields.Str(validate=validate.Length(max=15))

    @post_load
    def make_slice(self, data):
        return VethPeerLinkModel(**data)


class SliceConnectionSchema(Schema):
    br_slice = fields.Str(required=True, validate=validate.Length(max=15))
    veth_slice = fields.Nested(VethPeerLinkSchema)
    br_wifi = fields.Str(required=True, validate=validate.Length(max=15))
    veth_wifi = fields.Nested(VethPeerLinkSchema)

    @post_load
    def make_slice(self, data):
        return SliceConnectionModel(**data)


class PatchSchema(Schema):
    patch0 = fields.Str(validate=validate.Length(max=14))
    patch1 = fields.Str(validate=validate.Length(max=14))

    @post_load
    def make_slice(self, data):
        return PatchModel(**data)


class DefaultNetConfigSchema(Schema):
    vxlan = fields.Str(required=True, validate=validate.Length(max=14))
    seg = fields.Str(required=True, validate=validate.Length(max=14))
    patch = fields.Nested(PatchSchema)

    @post_load
    def make_slice(self, data):
        return DefaultNetConfigModel(**data)


class NetDeviceSchema(Schema):
    peer = fields.Nested(VethPeerLinkSchema, allow_none=True)
    ip_address = fields.Str(allow_none=True)
    ofport = fields.Int(allow_none=True)
    group_id = fields.Str(allow_none=True)
    vport_mac = fields.Str(allow_none=True)

    @post_load
    def make_slice(self, data):
        return NetDeviceModel(**data)


class DeviceSchema(TechSchema, DriverApp):
    mac = fields.Str(required=True, validate=validation.mac_address)
    description = fields.Str(required=True, validate=validate.Length(min=6, max=255))
    technology = fields.Str(required=True, validate=validation.technology)
    enabled = fields.Boolean(required=True)
    gateways = fields.List(fields.Str, allow_none=True, default=[])

    id = fields.Str(dump_only=True, validate=validation.mac_address)
    endpoint_id = fields.Str(dump_only=True)
    host = fields.Str(allow_none=True, dump_only=True)
    net = fields.Nested(NetDeviceSchema, allow_none=True, dump_only=True)
    action = fields.Nested(ActionSchema, allow_none=True, dump_only=True)

    @post_load
    def make_slice(self, data):
        data['mac'] = data['mac'].lower()
        if not data.get('endpoint_id'):
            data['endpoint_id'] = str(uuid.uuid4())
        if not data.get('id'):
            data['id'] = data['mac']
        return DeviceModel(**data)


class DeviceUpdateSchema(Schema):
    description = fields.Str(validate=validate.Length(min=6, max=255))
    technology = fields.Str(validate=validation.technology)
    enabled = fields.Boolean()


class SimpleDeviceSchema(Schema):
    id = fields.Str(required=True, validate=validation.mac_address)
    slice = fields.Str(required=True)
    action = fields.Nested(ActionSchema, allow_none=True, dump_only=True)

    @post_load
    def make_slice(self, data):
        return SimpleDeviceModel(**data)


class UpdatedAtSchema(Schema):
    updated_at = fields.DateTime(allow_none=True)

    @post_load
    def make_model(self, data):
        if not data.get('updated_at'):
            data['updated_at'] = datetime.now(tzutc())
        return UpdatedAtModel(**data)


class AppSchema(Schema):
    url = fields.Str(required=True, validate=[validation.url])
    labels = fields.List(fields.String, allow_none=True)
    id = fields.Str(dump_only=True)
    name = fields.Str(dump_only=True)
    updated_at = fields.DateTime(allow_none=True)
    status = fields.Dict(dump_only=True, allow_none=True)
    data = fields.Dict(dump_only=True)

    @post_load
    def make_slice(self, data):
        if not data.get('updated_at'):
            data['updated_at'] = datetime.now(tzutc())
        if not data.get('labels'):
            data['labels'] = []
        return AppModel(**data)


class AppSchemaLoad(Schema):
    url = fields.Str(required=True)
    labels = fields.List(fields.String, allow_none=True)
    id = fields.Str(dump_only=True)
    name = fields.Str(dump_only=True)
    updated_at = fields.DateTime(allow_none=True)
    status = fields.Dict(dump_only=True, allow_none=True)
    data = fields.Dict(dump_only=True)

    @post_load
    def make_slice(self, data):
        if not data.get('updated_at'):
            data['updated_at'] = datetime.now(tzutc())
        if not data.get('labels'):
            data['labels'] = []
        return AppModel(**data)


class AppStatusSchema(Schema):
    host_ip = fields.Str(allow_none=True)
    message = fields.Str(allow_none=True)
    phase = fields.Str(allow_none=True)
    pod_ip = fields.Str(allow_none=True)
    qos_class = fields.Str(allow_none=True)
    reason = fields.Str(allow_none=True)
    start_time = fields.DateTime(allow_none=True)
    container_statuses = fields.List(fields.Dict, allow_none=True)

    homing_host = fields.Str(dump_only=True, allow_none=True)
    mac = fields.Str(dump_only=True, allow_none=True)

    @post_load
    def make_slice(self, data):
        return AppStatusModel(**data)


class AppSw4IotSpecContainer(Schema):
    name = fields.Str(required=True)
    image = fields.Str(required=True)


class AppSw4IotSpec(Schema):
    kind = fields.Str(required=True)
    name = fields.Str(required=True)
    containers = fields.Nested(AppSw4IotSpecContainer, required=True, many=True)

class NewGatewaySchema(Schema):
    id = fields.Str()
    ip_address = fields.Str()

    @post_load
    def make_model(self, data):
        return NewGatewayModel(**data)

class TokenGatewayInstallSchema(Schema):
    key = fields.Str()
    creation_date = fields.DateTime()

    @post_load
    def make_model(self, data):
        return TokenGatewayInstallModel(**data)

class UserSchema(Schema):
    username = fields.Str()
    password = fields.Str()

    @post_load
    def make_model(self, data):
        return UserModel(**data)

class RevokedTokenSchema(Schema):
    id = fields.Str()
    jti = fields.Str()

    @post_load
    def make_model(self, data):
        return RevokedTokenModel(**data)
