import logging

from sw4iotdatabase.database import Sw4IotDatabase
from apscheduler.schedulers.blocking import BlockingScheduler

from src.jobs.container_config import container_net, delete_container_net
from src.jobs.gateway_install import install_gw
from src.jobs.network_setup import config_slice_security_nat, config_slices_net, restore_iptables_rules

logging.getLogger('apscheduler').setLevel(logging.ERROR)
logging.getLogger('sw4iot').setLevel(logging.INFO)
logging.getLogger('sw4iot_net_man').setLevel(logging.DEBUG)

FORMAT = '%(asctime)s - %(name)s - %(funcName)s - %(levelname)s - %(message)s'
logging.basicConfig(filename='/opt/softway4iot/logs/net-manager.log', filemode='a', format=FORMAT)
logger = logging.getLogger('NetManSW4IoT')
logger.setLevel(logging.INFO)


if __name__ == '__main__':

    logger.info("Applying iptables rules")
    restore_iptables_rules()

    db = Sw4IotDatabase(host='10.250.1.4')

    scheduler = BlockingScheduler(timezone="UTC")

    scheduler.add_job(container_net, 'interval', args=[db], seconds=5, id=container_net.__name__, replace_existing=True)
    scheduler.add_job(delete_container_net, 'interval', args=[db], seconds=5, id=delete_container_net.__name__,
                      replace_existing=True)

    scheduler.add_job(install_gw, 'interval', args=[db], seconds=5, id=install_gw.__name__, replace_existing=True)

    scheduler.add_job(config_slice_security_nat, 'interval',  args=[db], seconds=5, id=config_slice_security_nat.__name__,
                      replace_existing=True)

    scheduler.add_job(config_slices_net, 'interval', args=[db], seconds=5, id=config_slices_net.__name__, replace_existing=True)

    try:
        logger.info("Starting OrchSW4IoT scheduler jobs")
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        logger.error("Exit OrchSW4IoT scheduler jobs")
        scheduler.remove_all_jobs()
        logger.info("All jobs have been removed")
