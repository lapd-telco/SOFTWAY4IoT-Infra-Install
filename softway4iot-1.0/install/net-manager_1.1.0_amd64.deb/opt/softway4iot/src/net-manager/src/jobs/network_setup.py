from src.network_manager.gateway_manager import GatewayManager
from src.network_manager.gateway import Gateway
import logging

from sw4iotdatabase.models import SecurityTypeEnum, SliceNetModel
from sw4iotdatabase.schemas import SecuritySchema

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def install_policy_gateway_manager(nat_sec, slice_id):
    dropped_rule = GatewayManager().verify_drop_rule()

    if nat_sec and nat_sec.enabled:
        if dropped_rule:
            GatewayManager().del_nat_rule()
            logger.info("Enabling Internet access of slice {}".format(slice_id))

    elif nat_sec and not nat_sec.enabled:
        if not dropped_rule:
            GatewayManager().add_nat_rule()
            logger.info("Disabling Internet access of slice {}".format(slice_id))


def install_policy_gateway(gateway_id, nat_sec, slice_id):
    dropped_rule = Gateway(gateway_id).verify_drop_rule()
    logger.info("Drop: {}".format(dropped_rule))
    if nat_sec and nat_sec.enabled:
        if dropped_rule:
            Gateway(gateway_id).del_nat_rule()
            logger.info("Enabling Internet access of slice {} in Gateway {}".format(slice_id, gateway_id))

    elif nat_sec and not nat_sec.enabled:
        if not dropped_rule:
            Gateway(gateway_id).add_nat_rule()
            logger.info("Disabling Internet access of slice {} in Gateway {}".format(slice_id, gateway_id))


def config_slice_security_nat(db):
    """
    Enable or disable NAT rules of slice
    """
    for slice in db.get_slices():
        net = db.get_slice_net(slice.id)
        if net:
            nat_sec = db.get_slice_security(slice.id, SecurityTypeEnum.NAT)
            install_policy_gateway_manager(nat_sec, slice.id)

            gateways = db.get_slice_gws(slice.id)
            for gateway in gateways:
                install_policy_gateway(gateway.id, nat_sec, slice.id)


def config_slices_net(db):
    """
    Configure slice network, creating the network on Contiv plugin
    """
    for slice in db.get_slices():

        net = db.get_slice_net(slice.id)
        if not net:
            logger.info('Creating network to slice {}'.format(slice.id))

            slice_net = SliceNetModel(tenant="s{}".format(slice.id), network='s{}-net'.format(slice.id),
                                      group='s{}-group'.format(slice.id), nat_policy='s{}-nat-policy'.format(slice.id),
                                      subnet='10.250.1.0/16', gateway='10.250.1.1', netmask='255.255.0.0', dns='8.8.8.8')

            db.save_slice_security(slice.id, SecurityTypeEnum.NAT, SecuritySchema().load({"enabled": False}))
            db.save_slice_net(slice.id, slice_net)


def restore_iptables_rules():
    """
    Restore iptables rules when GM starts
    :return:
    """
    gm = GatewayManager()
    gm.restore_iptables_rules()
