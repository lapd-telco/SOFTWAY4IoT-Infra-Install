from src.comm.gateway_comm import GatewayComm
from src.utils.configuration import Configuration


class Gateway:
    def __init__(self, id):

        self.gateway_bridge_data = Configuration.get('GATEWAY', 'ip_prefix_br_data') + "." + str(id) + '.1'
        self.gateway_bridge_control = Configuration.get('GATEWAY', 'ip_prefix_br_control') + "." + str(id) + '.1'

        self.name_bridge_data = Configuration.get('GATEWAYMANAGER', 'name_bridge_data')
        self.name_bridge_control = Configuration.get('GATEWAYMANAGER', 'name_bridge_control')

        self.control = GatewayComm(id)

    def add_network_in_container(self, container_name, static_ip, mac_address, bridge='br-data'):
        """

        :param container_name: Name of container
        :param bridge: Name of bridge of connection
        :param static_ip: IP address if static
        :return:
        """
        gateway = self.gateway_bridge_control if bridge == self.name_bridge_control else self.gateway_bridge_data
        self.control.add_port_container(container_name, bridge, gateway, static_ip, mac_address)

    def del_network_in_container(self, container_name, bridge='br-data'):
        """

        :param container_name:
        :param bridge:
        :return:
        """
        self.control.del_port_container(container_name, bridge)

    def verify_drop_rule(self):
        """
        Verify if exist drop rule in ovs
        :return:
        """
        return self.control.verify_drop_rule()

    def add_nat_rule(self):
        """
        TODO
        :return:
        """
        self.control.add_drop_rule()

    def del_nat_rule(self):
        """
        TODO
        :return:
        """
        self.control.del_drop_rule()

