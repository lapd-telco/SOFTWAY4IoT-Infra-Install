import requests


class GatewayComm:
    def __init__(self, id):
        """
        Init
        :param id: Id of Gateway
        """
        self.id = id
        self.url = "http://" + "10.250." + str(id) + ".1" + ":5000/api/v1/"

    def __headers(self, token=False):
        headers = {
            'Content-Type': 'application/json',
        }
        if token:
            headers['X-Auth-Token'] = token
        return headers

    def redirect_port(self, ip_destination, in_port, destination_port, protocol='tcp'):
        """
        Redirect port to contaniner
        :return: None
        """
        path = self.url + "redirectport/"
        params = {'ip_destination': str(ip_destination), 'in_port': str(in_port),
                  'destination_port': str(destination_port), 'protocol': str(protocol)}

        r = requests.post(path, json=params, headers=self.__headers())
        print(r)

    def add_port_container(self, container_name, bridge, gateway, ip):
        """
        Add port in container
        :param ip:
        :param container_name:
        :param bridge:
        :param port:
        :param gateway:
        :return: None
        """
        path = self.url + "containerport/"
        params = {'container_name': str(container_name), 'bridge': str(bridge),
                  'gateway': str(gateway), 'ip': str(ip)}

        r = requests.post(path, json=params, headers=self.__headers())
        print(r)

    def del_port_container(self, container_name, bridge):
        """
        Delete port of container
        :param container_name:
        :param bridge:
        :return: None
        """
        path = self.url + "containerport/"
        params = {'container_name': str(container_name), 'bridge': str(bridge)}

        r = requests.delete(path, json=params, headers=self.__headers())
        print(r)

    def verify_drop_rule(self):
        """
        Verify in switch of exist drop rule
        :return: True if exist and False if not exist
        """
        path = self.url + "droprule/"

        r = requests.get(path, headers=self.__headers())
        print(r)

    def add_drop_rule(self):
        """
        Add rule of drop packets
        :return:
        """
        path = self.url + "droprule/"

        r = requests.post(path, headers=self.__headers())
        print(r)

    def del_drop_rule(self):
        """
        Delete rule of drop packets
        :return:
        """
        path = self.url + "droprule/"

        r = requests.delete(path, headers=self.__headers())
        print(r)
