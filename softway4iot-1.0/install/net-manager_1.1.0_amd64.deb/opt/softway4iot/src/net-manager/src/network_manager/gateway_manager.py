import socket

from src.comm.gateway_manager_comm import GatewayManagerComm
from src.utils.configuration import Configuration


class GatewayManager:
    def __init__(self):

        self.ip_address = self.get_ip()

        self.gateway_bridge_data = Configuration.get('GATEWAYMANAGER', 'gw_br_data')
        self.gateway_bridge_control = Configuration.get('GATEWAYMANAGER', 'gw_br_control')

        self.name_bridge_data = Configuration.get('GATEWAYMANAGER', 'name_bridge_data')
        self.name_bridge_control = Configuration.get('GATEWAYMANAGER', 'name_bridge_control')

        self.control = GatewayManagerComm()

    def get_ip(self):
        """
        IP address of hostname
        :rtype: str
        :return: IP address
        """
        return [(s.connect(('8.8.8.8', 53)), s.getsockname()[0], s.close()) for s in
                [socket.socket(socket.AF_INET, socket.SOCK_DGRAM)]][0][1]

    def add_network_in_container(self, container_name, static_ip, mac_adrress, bridge='br-data'):
        """
        Add network configuration in container
        :param container_name: Name of container
        :param bridge: Name of bridge of connection
        :param static_ip: IP address if static
        :return: None
        """
        gateway = self.gateway_bridge_control if bridge == self.name_bridge_control else self.gateway_bridge_data
        self.control.add_port_container(container_name, bridge, gateway, static_ip, mac_adrress)

    def del_network_in_container(self, container_name, bridge='br-data'):
        """
        Delete network configuration in container
        :param container_name:
        :param bridge:
        :return: None
        """
        self.control.del_port_container(container_name, bridge)

    def config_network_gateway(self, gateway_id, gateway_ip):
        """
        Configure VPN connection with Gateway
        :param gateway_id:
        :param gateway_ip:
        :return: None
        """

        self.control.setup_vpn(gateway_id, gateway_ip, self.ip_address)

    def verify_drop_rule(self):
        """
        Verify if exist drop rule in ovs
        :return: None
        """
        return self.control.verify_drop_rule()

    def add_nat_rule(self):
        """
        Block connections with Internet of Bridge Data
        :return:None
        """
        self.control.add_drop_rule()

    def del_nat_rule(self):
        """
        Allow connections with Internet of Bridge Data
        :return: None
        """
        self.control.del_drop_rule()

    def restore_iptables_rules(self):
        """
        Restore iptables rules
        :return: None
        """
        self.control.restore_iptable_rules()