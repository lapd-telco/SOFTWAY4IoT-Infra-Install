from src.network_manager.gateway import Gateway
from src.network_manager.gateway_manager import GatewayManager


def add_gateway(gateway_manager, id, ip):
    gw = Gateway(id, ip, 'labora', 22, '/home/marcos/.ssh/known_hosts', 'l@b0r@1NF', 'enp0s3',
                 '10.16.0.178', False)
    gw.clean_installation()
    gw.initial_configuration()

    add_gateway_in_gateway_manager(gw, id, gateway_manager)

    return gw


def add_gateway_manager():
    gm = GatewayManager()

    return gm


def add_gateway_in_gateway_manager(gateway, id, gateway_manager):
    gateway.configure_gw_gm()
    gateway_manager.add_gw_gm(id, gateway.ip_address)


def add_ip_in_container(gateway, container_name, bridge, port, ip):
    gateway.add_network_in_container(container_name, bridge, port, ip)


if __name__ == "__main__":

    gm = add_gateway_manager()
    gw1 = add_gateway(gm, 1, '10.16.0.159')
    gw2 = add_gateway(gm, 2, '10.16.0.149')

    add_ip_in_container(gw1, 'container133', 'br_data', 'eth2', '10.249.2.3/16')
