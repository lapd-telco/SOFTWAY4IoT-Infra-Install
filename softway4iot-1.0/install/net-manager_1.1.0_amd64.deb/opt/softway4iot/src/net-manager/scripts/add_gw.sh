#!/bin/bash

ip_remote=$1

# Interfaces:
IFACE_VXLAN_DATA=vxlan_data
IFACE_VXLAN_CONTROL=vxlan_control

# Add VXLAN bridge data:
echo "Add VXLAN"
ovs-vsctl add-port br-data $IFACE_VXLAN_DATA -- set Interface $IFACE_VXLAN_DATA type=gre options:remote_ip=$ip_remote

# Add VXLAN bridge comm:
ovs-vsctl add-port br-control $IFACE_VXLAN_CONTROL -- set Interface $IFACE_VXLAN_CONTROL type=vxlan options:remote_ip=$ip_remote
