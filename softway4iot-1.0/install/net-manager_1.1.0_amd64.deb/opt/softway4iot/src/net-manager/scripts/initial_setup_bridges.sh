#!/bin/bash

# Interfaces:
IFACE_LAN_CONTROL=c-control
IFACE_LAN_DATA=c-data

iface_wan=$1

# Params to configure NAT BR_DATA:
network_lan_data=$2

# Params to configure NAT BR_CONTROL:
network_lan_control=$3

gw_type=$4

#Required configs in Rasp:

if [ $gw_type -eq "1" ]
then
	echo "Apllying configs in Raspberry"
	ovs-vsctl set Open_vSwitch $(ovs-vsctl show | head -n 1) other_config:n-handler-threads=13
fi

# Configure BR_DATA:
echo "ADD Bridge data"
ovs-vsctl add-br br-data

echo "ADD Bridge data internet connection"
ovs-vsctl add-port br-data $IFACE_LAN_DATA -- set Interface $IFACE_LAN_DATA type=internal
ifconfig $IFACE_LAN_DATA $network_lan_data up

echo "1" > /proc/sys/net/ipv4/ip_forward
iptables -t nat -A POSTROUTING -o $iface_wan -s $network_lan_data ! -d $network_lan_data -j MASQUERADE
iptables -A FORWARD -d $network_lan_data -i $iface_wan -o $IFACE_LAN_DATA -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -s $network_lan_data -i $IFACE_LAN_DATA -j ACCEPT

ovs-ofctl add-flow br-data ip,priority=2,actions=DROP
ovs-ofctl add-flow br-data ip,nw_src=$network_lan_data,nw_dst=$network_lan_data,priority=8,actions=NORMAL

# Configure BR_CONTROL:
echo "ADD Bridge comm"
ovs-vsctl add-br br-control

echo "ADD Bridge comm internet connection"
ovs-vsctl add-port br-control $IFACE_LAN_CONTROL -- set Interface $IFACE_LAN_CONTROL type=internal
ifconfig $IFACE_LAN_CONTROL $network_lan_control up

echo "1" > /proc/sys/net/ipv4/ip_forward
iptables -t nat -A POSTROUTING -o $iface_wan -s $network_lan_control ! -d $network_lan_control -j MASQUERADE
iptables -A FORWARD -d $network_lan_control -i $iface_wan -o $IFACE_LAN_CONTROL -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -s $network_lan_control -i $IFACE_LAN_CONTROL -j ACCEPT

ovs-ofctl add-flow br-control ip,priority=2,actions=DROP
ovs-ofctl add-flow br-control ip,nw_src=$network_lan_control,nw_dst=$network_lan_control,priority=8,actions=NORMAL
