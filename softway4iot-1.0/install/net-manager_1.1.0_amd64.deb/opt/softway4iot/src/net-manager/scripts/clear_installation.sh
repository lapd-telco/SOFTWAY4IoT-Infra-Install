#!/bin/bash

ovs-vsctl del-br br-data
ovs-vsctl del-br br-control


iptables --flush
iptables --table nat --flush
iptables --delete-chain
iptables --table nat --delete-chain

ipsec stop

cat >> ./ipsec.secrets << EOF
# no configuration
EOF

cp ./ipsec.secrets /etc/ipsec.secrets
