from pyric import pyw
from pyroute2 import IPDB
from sw4iotdatabase import database
from sw4iotdatabase.models import InterfaceModel
from sw4iotdatabase.schemas import InterfaceSchema
from apscheduler.schedulers.blocking import BlockingScheduler
import logging

logging.basicConfig(filename='interfaces_monitor.log', filemode='w', level=logging.ERROR)
logger = logging.getLogger(__name__)

db = database.Sw4IotDatabase()

def up_interfaces(ifaces):
    with IPDB() as ipdb:
        with ipdb.interfaces[ifaces] as i:
            i.up()

def get_gw_conf_file():
    f = open('/opt/softway4iot/conf.softway4iot', 'r')
    if f.mode == 'r':
        fcontent = str(f.readline())
        ID_PREFIX = "NUMBER_GATEWAY_CONTROLL="
        fcontent = fcontent.replace(ID_PREFIX,'')
        GW_ID = int(fcontent)
        fcontent = str(f.readline())
        ETH_PREFIX = "PHYSICAL_NETWORK_INTERFACE="
        fcontent = fcontent.replace(ETH_PREFIX,'') 
        GW_ETH = str(fcontent)
        f.close()
        return GW_ID,GW_ETH.rstrip()

def wifi_list_interfaces():
    try:
        GW_ID,GW_ETH = get_gw_conf_file()
        # list saved interfaces
        saved_ifaces = {i.name: i for i in db.get_gw_interfaces(GW_ID, InterfaceModel.type.WIFI)}
        # plugged interfaces
        plugged_interfaces = {}
        for dev_name in [wiface for wiface in pyw.winterfaces()]:
            up_interfaces(dev_name)
            w0 = pyw.getcard(dev_name)
            iinfo = pyw.ifinfo(w0)
            dinfo = pyw.devinfo(w0)
            pinfo = pyw.phyinfo(w0)

            if 'AP' in pinfo['modes']:
                iface = InterfaceModel(type=InterfaceModel.type.WIFI, name=dev_name, device=dev_name,
                                       manufacturer=iinfo['manufacturer'], product=iinfo['chipset'], max_vnets=4,
                                       # TODO: fix this, remove max_vnet=4 and get this information, should subtract an iterface beacuse the physical interface is considered
                                       options={
                                           "bands": list(pinfo['bands'].keys()),
                                           "ciphers": list(pinfo['ciphers']),
                                           "mac": iinfo['hwaddr'],
                                           "enable": 'no',
                                           "eth": GW_ETH,
                                           "driver": iinfo['driver'],
                                           "mode": dinfo['mode']
                                       })
                plugged_interfaces[iface.name] = iface
                if iface.name not in saved_ifaces:
                    logger.info('Save Wi-Fi iface {} of gateway {}'.format(iface.name, GW_ID))
                    db.save_gw_interface(GW_ID, InterfaceModel.type.WIFI, InterfaceSchema().load(iface.to_dict()))

        # delete interfaces removed
        ifaces_to_delete = list(set(saved_ifaces.keys()) - set(plugged_interfaces.keys()))
        if len(ifaces_to_delete) > 0:
            logger.debug('Interfaces to delete {} on gateway {}'.format(ifaces_to_delete, GW_ID))

        for iface_name in ifaces_to_delete:
            logger.info('Delete iface {} on gateway {}'.format(iface_name, GW_ID))
            db.delete_gw_interface(GW_ID, InterfaceModel.type.WIFI, iface_name)
    except Exception as e:
        logger.error(e)

scheduler = BlockingScheduler(timezone="UTC")

scheduler.add_job(wifi_list_interfaces, 'interval', seconds=10, id=wifi_list_interfaces.__name__,
                      replace_existing=True)

try:
    logger.info("Starting Drivers scheduler")
    scheduler.start()
except SystemExit:
    logger.error("Exit Drivers scheduler")
    scheduler.remove_all_jobs()  # TODO remove this
    logger.info("All jobs have been removed")
